CREATE TABLE public.agentforce_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  public_session_token_hash text UNIQUE NOT NULL,
  agentforce_session_id text,
  next_sequence_id integer NOT NULL DEFAULT 1,
  language text NOT NULL DEFAULT 'en',
  status text NOT NULL DEFAULT 'active',
  request_in_progress boolean NOT NULL DEFAULT false,
  last_tool_name text,
  last_question_category text,
  message_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  last_activity_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days')
);

CREATE TABLE public.chat_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES public.agentforce_sessions(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  question_category text,
  tool_name text,
  language text,
  success boolean,
  error_category text,
  response_time_ms integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_agentforce_sessions_activity ON public.agentforce_sessions (last_activity_at);
CREATE INDEX idx_chat_events_session ON public.chat_events (session_id);
CREATE INDEX idx_chat_events_created ON public.chat_events (created_at);

GRANT ALL ON public.agentforce_sessions TO service_role;
GRANT ALL ON public.chat_events TO service_role;

ALTER TABLE public.agentforce_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_events ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER agentforce_sessions_touch
BEFORE UPDATE ON public.agentforce_sessions
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
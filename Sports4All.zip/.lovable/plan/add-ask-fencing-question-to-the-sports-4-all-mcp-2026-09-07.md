# Add `ask_fencing_question` to the Sports 4 All MCP

Adds one new read-only tool. No existing tool is renamed, removed, or changed in behavior, and the consumer-facing site is untouched.

## What the tool does

A caller (for example the ChatGPT app) sends a general fencing question — wheelchair fencing, the three weapons, equipment, getting started, Paralympic pathways — and the Salesforce Agentforce agent writes the answer. The middleware only validates the input, wraps it in a scoped instruction block, forwards it, and tidies the reply. It never answers on its own.

## Input the tool accepts

- `question` (required) — trimmed, non-empty, up to 1,500 characters
- `language` — defaults to `en`, up to 20 characters
- `conversation_context` — optional short summary, up to 2,000 characters
- `agentforce_session_id` — optional, to continue an earlier conversation
- `sequence_id` — whole number 1–1,000, defaults to 1 for a new conversation

Invalid input returns a plain MCP error ("Please enter a fencing question.") without ever reaching Salesforce.

## What comes back

Readable answer text plus structured fields: `answer`, `agentforce_session_id`, `next_sequence_id`, `language`, and `suggested_follow_up_questions` only when the agent actually offers them. Never the raw Salesforce payload, tokens, the internal prompt, or a stack trace.

Error wording:
- timeout — "The Fencing for All assistant is taking longer than expected. Please try again."
- unavailable — "The Fencing for All assistant is temporarily unavailable. Please try again shortly."
- expired/invalid session — a retryable error telling the caller to start a fresh session

## Technical notes

- New file `src/lib/mcp/tools/ask-fencing-question.ts` using `defineTool` with Zod validation, matching the project's existing annotation convention (`readOnlyHint: true`, `destructiveHint: false`, `openWorldHint: false`), registered in `src/lib/mcp/index.ts`.
- The prompt block is the exact "Fencing for All guide" instruction set from the request, with `{{language}}`, `{{question}}`, and the context placeholder substituted; built in the tool file rather than through the generic `buildPrompt`, since it needs verbatim instructions.
- Reuses `src/lib/mcp/agentforce.ts` unchanged for token minting, caching, session start (new UUID external session key), and synchronous message send. Language is passed as the Agentforce end-user language variable on session start where the API accepts it.
- Session concurrency: a small in-memory map of in-flight session IDs. A second message against a session already in flight returns a retryable error instead of racing.
- Response normalization extracts the answer text and, when the agent's reply clearly lists follow-up questions, lifts them into `suggested_follow_up_questions`; no invented content.
- Mock mode: when `MOCK_AGENTFORCE=true`, returns a clearly labelled mock answer with a mock session id, `next_sequence_id`, and the selected language. Never used when the flag is off.
- Errors continue to pass through the existing `safeErrorMessage` redaction. Logging is limited to error category, timestamp, tool name, and status — never question text or credentials.

## Tests

Add Vitest (dev dependency + `test` script) with `src/lib/mcp/__tests__/ask-fencing-question.test.ts`, mocking the Agentforce client so nothing hits Salesforce:

- the registered tool list includes `ask_fencing_question` with read-only, non-destructive annotations
- `question` required; empty rejected; over 1,500 characters rejected; `sequence_id` outside 1–1,000 rejected — all without calling Agentforce
- `language` defaults to `en`
- no session id supplied → a new session is started; session id supplied → reused, no duplicate session
- `next_sequence_id` is the sent sequence plus one
- the answer text comes from the mocked agent, not the middleware
- credentials and raw Salesforce error bodies never appear in a tool result
- the four existing tools still build their prompts and results as before

## Live verification (after publish)

Republish, then against `https://sports-4-all.org/api/public/mcp`: `initialize`; `tools/list` showing five tools with the new schema and annotations; a live call with "Can my daughter fence from a wheelchair?"; a follow-up using the returned session and sequence to confirm context carries; plus the épée/foil/sabre, all-three-weapons, and Paralympic-qualification questions. Full transcript reported back with everything sensitive redacted. Not reported complete until deployed `tools/list` and at least one live agent call are confirmed.

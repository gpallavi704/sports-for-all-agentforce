# Run the MCP test flow (fencing)

Scope: verification only. No code or configuration changes, no new sports or NGB data. Fencing stays the only sport for now.

## What gets tested

Against the live endpoint `https://sports-all-connect.lovable.app/api/public/mcp`, one call each:

1. `initialize` — confirm protocol handshake and server info.
2. `tools/list` — confirm all four tools with their input schemas.
3. `tools/call` on each tool, with fencing-focused inputs:
   - `find_sports_programs` — e.g. fencing, Denver CO, youth age.
   - `get_program_details` — follow-up on a program named in the first reply, reusing the returned `session_id` and `sequence_id`.
   - `save_participant_preferences` — a sample participant preference set.
   - `request_human_assistance` — a sample escalation request.

Each call reuses the session returned by the previous one so the run reads as a single continuous conversation with the agent.

## What I report back

For each step: the request inputs, the agent's reply text, and the returned `session_id` / `sequence_id` / `mock` flag. All credentials and tokens stay redacted; nothing secret is printed.

If a call fails, I report the safe error message and the likely cause (agent configuration vs. endpoint) without changing code — any fix would come as a follow-up.

## Technical notes

Calls are made as JSON-RPC POSTs with `Accept: application/json, text/event-stream` against the published endpoint, so the results reflect the real deployed server and the real Agentforce agent, not a local build.

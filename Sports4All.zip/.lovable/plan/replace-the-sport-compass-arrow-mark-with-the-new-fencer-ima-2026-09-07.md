# Replace the Sport Compass arrow mark with the new fencer image

The small navy circle with a diagonal arrow currently stands in for Sport Compass. It gets replaced by the uploaded blue fencer image everywhere the avatar appears.

## What changes

- The uploaded fencer image becomes a hosted app image.
- Every place the assistant's mark shows uses that image instead of the arrow:
  - the chat header, next to the assistant's name
  - beside each answer in the conversation
  - the "thinking" indicator while an answer is loading
- The image keeps its round shape and current sizes (40px in the header, 36px in the list), so nothing shifts in the layout.
- It stays decorative for screen readers, matching today's behaviour.

## Technical notes

- Create a CDN pointer from `user-uploads://ChatGPT_Image_Sep_7_2026_01_21_44_PM.png` via `lovable-assets create` into `src/assets/sport-compass-avatar.png.asset.json`.
- In `src/components/chat/FencingChat.tsx`, swap the inline `<svg>` in `AgentAvatar` for an `<img>` using the imported pointer URL, keeping the `size` prop, `rounded-full`, ring styling, and `aria-hidden`. The three call sites (lines 130, 372, 426) are unchanged.
- Verify with `bunx tsgo --noEmit`, then a Playwright pass on `/ask` at 390 and 1280 to confirm the mark renders crisply in the header and beside answers.

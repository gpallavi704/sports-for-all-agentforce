# Fix: the assistant forgets the previous question

## What I found

The agent side is not the problem — the site does save an Agentforce conversation and does pass it back. The problem is that the browser is losing its link to that saved conversation between messages.

Evidence from the stored session records: every session row has a message count of at most 1, and several rows were created seconds apart with no messages at all. In other words, each message you send is being treated as a brand-new visitor, so a fresh Agentforce conversation is started and your "yes" arrives with no memory of the wheelchair question.

The most likely cause is the browser cookie the site uses to recognise a returning visitor. It is set as `SameSite=Lax`, which browsers refuse to send back when the page runs inside the Lovable preview frame (and in some privacy modes). No cookie back means no session match, so a new one is created every time.

Note: this diagnosis is strongly supported by the session records but not yet proven end to end. Step 1 below confirms it before anything else changes.

## Plan

1. **Confirm the cause.** Run a two-message conversation against the running site and check whether both messages land on the same session record. Record whether the session cookie comes back on the second request.

2. **Make the session survive between messages.**
   - Send the visitor cookie as `SameSite=None; Secure` when the page is served over HTTPS (works inside the preview frame and on the live domain), keeping `Lax` for local HTTP.
   - Add a cookie-free fallback: the chat endpoint also returns the same opaque visitor token in the response body, the browser stores it alongside the saved messages, and sends it back on the next request. The endpoint accepts either the cookie or that token. It stays opaque and hashed — no Agentforce or Salesforce identifiers ever reach the browser.
   - "Start New Conversation" clears the stored token as well as the visible messages.

3. **Give the agent better context for short replies.** A one-word "yes" carries almost no meaning on its own, so widen the conversation summary sent with each question from the last 4 short snippets to the last 6 turns with a longer allowance (still capped, still no storage of transcripts in the database).

4. **Tighten session recovery.** Only discard the saved Agentforce conversation when the service reports the session as expired or invalid, rather than on any general failure, so a single hiccup does not silently restart the conversation.

5. **Verify before reporting done.**
   - Ask "Can my daughter fence from a wheelchair?", then reply "yes" and confirm the second answer follows on from the first.
   - Confirm the session record now shows a message count of 2 or more with the same Agentforce conversation.
   - Confirm a page refresh restores both the visible messages and the same server-side conversation.
   - Confirm "New conversation" starts a genuinely fresh one.

## Technical notes

- Files touched: `src/lib/chat/session.server.ts` (cookie attributes, token resolution), `src/routes/api/sports-for-all-chat.ts` (accept token from body, return it, narrow the error-path session reset), `src/components/chat/useChat.ts` (store/send the token, wider `conversationContext`).
- No database schema change; no change to the MCP endpoint or the `ask_fencing_question` tool.
- Nothing sensitive is added to the browser: the token is random, opaque, and only its SHA-256 hash is stored server-side.

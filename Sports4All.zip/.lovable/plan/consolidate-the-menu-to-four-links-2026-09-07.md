# Consolidate the menu to four links

The top menu goes from seven links to four. Nothing is lost — the pages that leave the menu have their content moved into the page that absorbs them, and their old web addresses forward automatically.

## New menu

1. **Fencing for All** — absorbs *Explore Fencing* and *Paralympic Pathway*
2. **Accessibility** — unchanged
3. **How It Works** — unchanged
4. **About** — absorbs *Our Impact*

## What moves where

**Fencing for All** keeps its three intro cards ("Start at Any Age", "Adapt the Sport", "Choose Your Weapon"), then continues with two new sections on the same page:
- "Foil, épée and sabre" — the weapon comparison from Explore Fencing
- "From first lesson to the Paralympics" — the six-step pathway
- Jump links at the top of the page so a visitor can skip straight to either section, and the "Ask Sport Compass" button stays at the end.

**About** keeps its current opening and "How this was built", then continues with the Our Impact material (its long sections move over as-is, in their existing order, with the same in-page anchors so the section links keep working).

## Old addresses keep working

- `/explore` forwards to the weapons section of Fencing for All
- `/pathway` forwards to the pathway section of Fencing for All
- `/impact` forwards to About

Anywhere the site links to those pages — the homepage cards, the footer groups, the "Responsible AI" note, and the homepage `#explore` shortcut — is repointed to the new locations in the same pass, so no link goes through a redirect.

## Footer

The footer still lists everything, but reorganised to match: Explore Fencing, Paralympic Pathway and Our Impact become section links on their new parent pages rather than separate destinations.

## Technical notes

- Extract the body of `explore.tsx` and `pathway.tsx` into `src/components/site/WeaponsSection.tsx` and `src/components/site/PathwaySection.tsx` (with `id="weapons"` / `id="pathway"`); render both from `src/routes/fencing-for-all.tsx`.
- Move the section components in `src/routes/impact.tsx` into `src/components/site/impact/` and render them from `src/routes/about.tsx`, preserving existing element ids (`responsible-ai`, `accessibility`, etc.).
- Replace `explore.tsx`, `pathway.tsx` and `impact.tsx` with routes whose `beforeLoad` throws `redirect({ to: "/fencing-for-all", hash: "weapons" | "pathway" })` and `redirect({ to: "/about" })`. This keeps the URLs valid rather than 404ing.
- Update `NAV` and the footer groups in `src/components/site/SiteChrome.tsx`, the card list and `HASH_ROUTES` in `src/routes/index.tsx`, and the `/impact` link in `src/components/site/ResponsibleAiNote.tsx`.
- Merge the head metadata: `/fencing-for-all` and `/about` descriptions widen to cover the absorbed content; redirect routes need no metadata.
- Verify with a typecheck, the build log, and a browser pass over the four pages plus the three old addresses.

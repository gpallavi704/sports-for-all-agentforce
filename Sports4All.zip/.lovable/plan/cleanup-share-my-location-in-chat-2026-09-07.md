# Cleanup + "Share my location" in chat

## 1. Remove the non-production diagnostics panel

The collapsible "Non-production diagnostics" box at the bottom of the home page goes away entirely, along with the code that fetches it. The behind-the-scenes diagnostics check itself stays available, it just no longer renders on the page.

## 2. Remove two privacy items

- The small "Privacy" link in the chat header (next to New conversation / Full screen).
- The "Privacy and data use" panel on the Our Impact page.

Anything that pointed at that panel (the "Privacy and data use" link inside the "How this assistant works" note under the chat) is removed too, so no link leads to a section that no longer exists.

Kept as-is: the footer "Contact us" line, and the "Reporting a problem" email on Our Impact.

## 3. Share my location when the agent asks for one

When an answer asks where the visitor is (for example "What city or ZIP code are you in?"), a "Share my location" button appears under that answer. Nothing happens unless the visitor taps it.

Flow when tapped:

1. The browser shows its own permission prompt.
2. On allow, the coordinates are turned into a nearby place name (for example "Denver, Colorado, US"). Only that place name is sent to the agent, as a normal follow-up message — coordinates are never sent or stored.
3. On block or failure, a short line appears: location isn't available, please type your city or ZIP code instead. Typing still works exactly as today.

The button also appears in the small set of follow-up chips, so it is reachable by keyboard and announced to screen readers like the existing chips.

## Technical notes

- `src/routes/index.tsx`: delete the `Diagnostics` component and its use in `Index`; drop the now-unused `useState`/`useEffect` imports if nothing else needs them.
- `src/components/chat/FencingChat.tsx`: remove the `#privacy` anchor in the header; add location detection and the button.
  - Detection: a small helper that flags an agent message whose text asks for a location (matches on zip / postal code / what city / where are you located / your area, case-insensitive), reusing the vocabulary already in `src/lib/chat/routing.ts`.
  - Geolocation: `navigator.geolocation.getCurrentPosition` with `enableHighAccuracy: false`, 10s timeout; guard for browsers without the API and for a non-secure context.
  - Reverse geocode: `POST /api/reverse-geocode` (new server route) takes lat/lng rounded to 2 decimals and returns `{ place }`. The route calls BigDataCloud's keyless reverse-geocode endpoint server-side and returns city + region + country. On failure it returns the rounded coordinates' nearest-known fallback of `null`, and the UI then asks the visitor to type their city.
  - The resulting place name is sent through the existing `ask(...)` path with intent `find_sports_programs` so routing and session continuity are unchanged.
- `src/routes/impact.tsx`: delete the `id="privacy"` "Privacy and data use" card from the Responsible AI section.
- `src/components/site/ResponsibleAiNote.tsx`: remove the link to `/impact#privacy`.
- No database, MCP tool, or Agentforce prompt changes.

## Verification

Typecheck, run the existing tests, check the build log, then load the home page in a headless browser to confirm the diagnostics box and the Privacy link are gone and the chat still answers.

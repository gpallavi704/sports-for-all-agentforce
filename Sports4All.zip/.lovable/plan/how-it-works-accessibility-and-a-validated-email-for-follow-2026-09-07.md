# How It Works, Accessibility, and a validated email for follow-up

Three changes: a much fuller How It Works page, the accessibility commitment moved from About onto the Accessibility page, and a required, validated email address on the "ask a program specialist to follow up" form.

## 1. Enhance How It Works

The page keeps its heading and its three numbered steps, but each step becomes a proper card with a short example of a real question and the kind of answer that comes back. Four new sections follow:

- **A closer walkthrough** — the three steps expanded, each with an example question ("Can my daughter fence from a wheelchair?", "Find an accessible program near Denver", "Ask someone to follow up") and what happens next.
- **What Sport Compass can and can't do** — two side-by-side lists: general guidance on adaptive fencing, equipment, weapons, getting started and pathways versus official eligibility, classification, qualification rules and current club availability, which always route to USA Fencing.
- **What gets shared, and when** — plain language: questions and answers stay in the conversation; nothing is sent to the organization unless you fill in the follow-up form or agree to save preferences; contact details are only sent when you choose to provide them.
- **Behind the scenes** — a simple, text-based flow (you → this site → the Sports 4 All agent → trusted fencing information) with a one-line note that credentials and internal details never reach the browser. Rendered as accessible markup, not an image.

Page ends with the existing "Ask Sport Compass" button. Head/meta description updated to match the fuller page.

## 2. Move the accessibility section to /accessibility

- The "Accessibility is the product, not an add-on" section — the built-in list, the preferences card with the "Open accessibility options" button, and the accessibility statement (target, supported features, known limitations, reporting a problem) — moves out of About and onto the Accessibility page, below the existing "Fencing From a Wheelchair" content.
- On the Accessibility page it becomes a plain section (not part of the impact scorecard styling), with the same `#accessibility` anchor so existing links still land in the right place.
- Footer link "Accessibility Statement" repoints from `/about#accessibility` to `/accessibility#accessibility`.
- About keeps everything else; the impact scorecard row for Accessibility stays, with a link across to the Accessibility page.

## 3. Require and validate the email address

In the "ask a program specialist to follow up" form inside the chat:

- Email address becomes its own always-visible, required field, regardless of whether email or phone is the preferred contact method.
- When phone is the preferred method, the phone number field is also shown and required.
- Validation happens on submit and on leaving the field: the email must be a real-looking address (single @, a domain with a dot, no spaces, under 254 characters). An invalid or empty value shows an error message under the field, moves focus there, and blocks sending.
- Errors are announced to screen readers and tied to the field with `aria-describedby` / `aria-invalid`, consistent with the rest of the site.
- On success the request sends as it does today, with `contact_email` always included and `contact_phone` added when phone is preferred.

## Technical notes

- `src/routes/how-it-works.tsx` — expanded content, new sections, updated head description.
- `src/components/site/ImpactSections.tsx` — export the accessibility section instead of rendering it inside the impact stack; About drops it.
- `src/routes/accessibility.tsx` — renders the accessibility section after the wheelchair hero.
- `src/components/site/SiteChrome.tsx` — footer link repointed.
- `src/components/chat/FencingChat.tsx` — `AssistanceForm` gains `email` and `phone` plus an `errors` state; a small `isValidEmail` helper (shared with a unit test) validates on blur and submit.
- Add `src/lib/chat/__tests__` coverage for the email validator; run typecheck, the test suite and a Playwright pass over `/how-it-works`, `/accessibility`, `/about` and the follow-up form.

# Fix the "assistance" configuration warning

## What is happening

The "Run this scenario" button for **Scenario 5: Human assistance** on the About page sends the shorthand `assistance` as the tool name. The assistant's real tool is called `request_human_assistance`, so the chat looks for a tool named `assistance`, finds nothing, and shows the configuration warning instead of answering.

Nothing is missing from the assistant itself — all five tools, including human assistance, are already published and listed.

## The fix

1. Change the Scenario 5 button so it sends the real tool name `request_human_assistance`.
2. Make the chat tolerant of anything unexpected arriving in the address bar: the `/ask?intent=...` link only accepts one of the five real tool names, and anything else is ignored so the assistant simply answers the question normally. No more warning banner can be triggered by a bad link.
3. Leave the warning banner itself in place — it only appears in preview and is genuine feedback when something really is misconfigured.

## End-to-end test after the change

- Click "Run this scenario" on Scenario 5 from About and confirm a real answer comes back with no warning.
- Use the "Ask a program specialist to follow up" form in the chat and confirm the request is acknowledged.
- Visit `/ask?intent=nonsense&q=...` and confirm it answers normally with no warning.
- Confirm the four other scenarios still answer.

## Technical notes

- `src/components/site/ImpactSections.tsx`: `SCENARIOS` type becomes `intent?: ChatTool`; Scenario 5 uses `"request_human_assistance"`.
- `src/components/site/ask.ts` and `src/routes/ask.tsx`: narrow the intent through a shared `parseTool(value): ChatTool | undefined` guard exported from `src/lib/chat/routing.ts`, checking against the `ChatTool` union.
- `src/components/chat/FencingChat.tsx` line ~291: drop the `as never` cast and use the guard.
- No MCP or server changes; `bunx tsgo --noEmit`, `bunx vitest run`, and a Playwright pass against `http://localhost:8080`.

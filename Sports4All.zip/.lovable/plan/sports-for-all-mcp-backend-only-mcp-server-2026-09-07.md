# Sports for All MCP — backend-only MCP server

Build a backend-only MCP (Model Context Protocol) server on this app. No consumer-facing website, no database. It exposes four text tools that talk to a Salesforce Agentforce agent, with all credentials held server-side.

## Endpoint

Public MCP endpoint, reachable over HTTPS at:

```text
https://<your-app>.lovable.app/api/public/mcp
```

Public means anyone with the URL can call the tools and consume the Agentforce agent — that is what you selected. `MCP_SHARED_SECRET` will still be supported: if you later set it, calls without the matching header are rejected, so you can lock the endpoint down at any time without a code change.

Protocol support: `initialize`, `notifications/initialized`, `ping`, `tools/list`, `tools/call`, plus CORS and `OPTIONS` preflight.

## Tools

- `find_sports_programs` — search programs by location, sport, age, and other filters.
- `get_program_details` — full detail for one program by identifier.
- `save_participant_preferences` — record a participant's preferences.
- `request_human_assistance` — hand the conversation to a person.

Each tool validates its input, caps free-text length, and returns a clear MCP error on failure. Every tool accepts an optional existing Agentforce session ID and sequence ID so a multi-turn conversation can continue.

## Secrets

Requested through the secure Secrets form — never in code, logs, responses, or any browser-visible variable.

Required: `SALESFORCE_MY_DOMAIN_URL`, `SALESFORCE_CLIENT_ID`, `SALESFORCE_CLIENT_SECRET`, `SALESFORCE_AGENT_ID`.

Optional: `AGENTFORCE_API_BASE_URL`, `AGENTFORCE_BYPASS_USER`, `MCP_SHARED_SECRET`, `MOCK_AGENTFORCE`.

Per your choice, real credentials are required to run; `MOCK_AGENTFORCE=true` remains available as an escape hatch but is off by default.

## Salesforce connection

OAuth client-credentials flow mints short-lived access tokens, cached in memory only and refreshed shortly before expiry. Tokens never appear in tool output or error text. The Agentforce Agent API is used to start a session and send synchronous text messages.

## Technical notes

- `@lovable.dev/mcp-js` with the TanStack Vite plugin mounted at `/api/public/mcp`; tools live in `src/lib/mcp/tools/`, registered in `src/lib/mcp/index.ts`.
- Shared Agentforce client in `src/lib/mcp/agentforce.ts`: token mint + cache, session start, synchronous message send, error sanitisation, shared-secret check.
- Zod input schemas per tool with length caps; failures returned as `ToolError`.
- Stateless — no tables, no migrations. Session continuity is caller-supplied IDs only.
- A small favicon is added so the connector list shows an icon.

## Delivery

After the code is in place I publish the app, give you the exact endpoint URL, open the secure Secrets form for the four Salesforce values, and then run one `initialize`, one `tools/list`, and one `tools/call` against the live endpoint, with all secret values redacted in the output.

A custom ChatGPT component is out of scope until these four text tools work in ChatGPT developer mode.

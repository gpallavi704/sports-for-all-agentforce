# Accessibility widget + fix the page jump on load

## 1. Stop the page from scrolling itself

When any page opens, the chat card quietly pulls the whole window down to the
bottom of its message list. Fix: keep that auto-scroll inside the chat's own
message area and skip it on first render, so the page stays exactly where the
visitor landed. Opening a page, refreshing, and following a link all keep the
top of the page in view; sending a message still scrolls the conversation to
the newest reply.

## 2. Accessibility widget

A floating button in the bottom-right corner on every page, labelled
"Accessibility options", opening a small panel with:

- Text size: Normal / Large / Extra large
- High contrast mode
- Reduce motion
- Underline all links
- Readable (dyslexia-friendly) font
- Reset all

Behaviour:

- Choices are remembered in the visitor's browser and re-applied on every page.
- The panel opens with the keyboard, traps focus while open, closes on Escape,
  and returns focus to the button.
- The button is a full 44x44 tap target and never covers the chat send button
  on small screens.
- Reduce motion also respects the visitor's system setting automatically, as
  the site already does.
- A "Accessibility options" link is added to the footer that opens the same panel.

## Technical notes

- New `src/components/site/AccessibilityWidget.tsx`, rendered once inside
  `SiteChrome` so it appears on every route; a small hook stores preferences in
  `localStorage` under `s4a_a11y` and writes `data-*` attributes on `<html>`.
- Styling is driven from `src/styles.css` via `html[data-a11y-contrast="high"]`,
  `html[data-a11y-text="lg|xl"]`, `html[data-a11y-motion="reduce"]`,
  `html[data-a11y-links="underline"]`, `html[data-a11y-font="readable"]` — all
  using existing design tokens, no hardcoded colours.
- Preferences are read in an effect after hydration to avoid a server/client
  mismatch.
- Panel built on the existing shadcn Popover/Dialog primitive so keyboard and
  ARIA behaviour is correct.
- Scroll fix in `src/components/chat/FencingChat.tsx`: replace the
  `listEndRef.scrollIntoView` effect with a scroll of the message container's
  own `scrollTop`, guarded by a first-render ref.
- Verify with a typecheck, the existing tests, and a browser pass checking
  scroll position on load plus keyboard operation of the widget.

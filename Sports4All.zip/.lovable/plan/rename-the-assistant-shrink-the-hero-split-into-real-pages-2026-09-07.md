# Rename the assistant, shrink the hero, split into real pages

## 1. Rename to "Sport Compass"

Replace every user-visible "Fencing for All Assistant" / "Fencing for All Agent" label with **Sport Compass**:

- Chat header title and full-screen label, welcome message ("Hi! I'm Sport Compass, powered by Agentforce…"), the message input's screen-reader label.
- Hero primary button: "Ask Sport Compass".
- Nav button: "Ask Sport Compass" (shortened to "Ask the Agent" is dropped).
- Footer disclaimer and the "How It Works" copy.
- Page titles/descriptions in each page's metadata.
- The timeout error text on the server ("Sport Compass is taking longer than expected…").

The section name "Fencing for All" stays as the program name; only the assistant is renamed.

## 2. Shrink the hero

Reduce the hero so the chat card is visible with little or no scrolling on a laptop:

- Cut vertical padding roughly in half and tighten the spacing between headline, copy and buttons.
- Slightly smaller headline at large sizes; shorter supporting sentence.
- Constrain hero image height so the two photos stay a balanced band rather than a full-height column.
- Keep both CTAs, the trust line and all image alt text.

## 3. Separate pages instead of one scrolling page

New routes, each with its own title/description metadata and an `<h1>`:

| Page | Route | Content moved from home |
| --- | --- | --- |
| Home | `/` | Hero + chat card + short intro links to the other pages |
| Fencing for All | `/fencing-for-all` | "Fencing Is for Everyone" cards |
| Explore Fencing | `/explore` | Weapon comparison table |
| Accessibility | `/accessibility` | "Fencing From a Wheelchair" |
| Paralympic Pathway | `/pathway` | "From First Lesson to the Paralympics" |
| How It Works | `/how-it-works` | The three-step explanation |
| About | `/about` | Sports 4 All expansion copy |
| Ask Sport Compass | `/ask` | Dedicated full-width chat page |

- Navigation and footer move into the shared root layout so they appear on every page, using real links with a visible active state, keyboard accessible, same mobile menu.
- The chat stays on the home page **and** gets its own `/ask` page.
- Every "ask a question" button on a content page navigates to `/ask` carrying the question, which is submitted automatically on arrival — still a real call to the agent, no canned answers.
- Buttons on the home page keep working as they do today (they fill and send in the chat card already on screen).
- The old anchor links (`/#explore` etc.) redirect to the matching new page so shared links keep working.

## Technical notes

- New files under `src/routes/`: `fencing-for-all.tsx`, `explore.tsx`, `accessibility.tsx`, `pathway.tsx`, `how-it-works.tsx`, `about.tsx`, `ask.tsx`; nav/footer extracted to `src/components/site/`.
- The pending question is passed via a search param on `/ask` (e.g. `?q=…`) read once on mount, then cleared from the URL; `useChat` and the existing `s4a:ask` event handling stay as they are.
- Chat session storage, sequence handling, consent flows and the MCP endpoint are untouched.
- Skip-to-content link, focus styles, 44px targets and reduced-motion behaviour carry over unchanged.

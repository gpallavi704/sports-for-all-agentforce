# Rename About to Impact and clean up the page

## What changes for visitors

- The menu item **About** becomes **Impact**, and the page lives at **/impact**. The old **/about** address forwards there, so existing links keep working.
- The page opens once, not twice: today it starts with an "About Sports 4 All" intro and then a second "Fencing for All: Agentforce for Good" hero. These merge into a single opening that covers who Sports 4 All is for, that fencing is the start, how it was built with USA Fencing, and the "Ask Sport Compass" button.
- Hackathon judging language goes: the "— 20%", "— 15%", "— 10%" tags in section labels and the whole "How Sports 4 All addresses the judging criteria" scorecard with its focus-area badges. The link to the accessibility statement that lived in the scorecard moves into the accessibility mention that stays on the page.
- The long bullet lists (the challenge, responsible AI, the adoption model, originality) get tightened into fewer, punchier points. No topic is dropped — the same ground is covered in shorter sentences.
- Spacing, headings and card styling get evened out across the page so every section uses the same rhythm.
- The **Contact us** line at the bottom of every page is removed site-wide. The accessibility "Reporting a problem" email stays.

## Sections kept, in order

One merged opening, the challenge, who it is for and impact measures, responsible AI, originality and how a question travels, try the complete journey with live system status, scale to every sport, under the hood, Agentforce beyond the website, and agent observability.

## Technical details

- `src/routes/impact.tsx` becomes the real page: its own `head()` (title, description, og:title, og:description, og:type, twitter:card, og:url and canonical pointing at `https://sports-4-all.org/impact`), rendering the merged opening plus `ImpactSections`.
- `src/routes/about.tsx` becomes a `beforeLoad` that throws `redirect({ to: "/impact" })`.
- `src/components/site/ImpactSections.tsx`: drop the percentage suffixes from `eyebrow` strings, delete the `Scorecard` section along with `CRITERIA` and `BADGES`, move its accessibility link into the responsible-AI section, replace the standalone navy hero with the merged opening owned by the route, shorten the `Bullets` arrays, and normalise section padding/card classes. The `id="impact"` anchor and all other section ids stay.
- `src/components/site/SiteChrome.tsx`: nav item becomes `{ to: "/impact", label: "Impact" }`; the "Sports 4 All" footer group becomes Impact / How It Works (the duplicate "Our Impact" entry goes); the `Contact us` paragraph is deleted.
- `src/routes/index.tsx` hash map entries `#about` and `#privacy` point to `/impact`; `src/components/site/ResponsibleAiNote.tsx` links to `/impact`.
- `src/routes/README.md` route table updated.
- Verify with `bunx tsgo --noEmit`, `bunx vitest run`, and a Playwright pass over `/impact`, `/about` and the footer.

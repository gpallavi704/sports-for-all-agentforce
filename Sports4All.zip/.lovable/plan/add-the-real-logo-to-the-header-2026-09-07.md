# Add the real logo to the header

Replace the placeholder circle-and-text brand mark in the site header with the uploaded
Sports-4-All.org / Fencing for All logo, and drop the "Sports 4 All" text next to it.

## What changes

- The header link at the top left shows the uploaded logo image only — no circle placeholder,
  no "Sports 4 All" wording beside it. It still links to the home page.
- The logo is sized to fit the header height (about 40px tall on phones, 48px on larger
  screens) and keeps its proportions, so the header does not grow taller or shift.
- Because the logo image now carries the words, the link gets an accessible name
  ("Sports 4 All — Fencing for All") through the image alt text, so screen readers and
  keyboard users still hear the brand.
- The site name stays unchanged everywhere else: page titles, the footer heading, and body
  copy are untouched.
- The browser tab icon is also updated to a small square crop of the logo so the tab matches
  the header, replacing the default icon.

## Technical notes

- Upload `user-uploads://ChatGPT_Image_Sep_7_2026_01_18_20_PM.png` through the Lovable assets
  CLI to `src/assets/logo-sports-4-all.png.asset.json`; import the pointer in
  `src/components/site/SiteChrome.tsx` and render `<img src={logo.url} alt="..." />`.
- Header brand markup lives at `src/components/site/SiteChrome.tsx` lines 21–24; remove the
  `blade-line` span and the text node.
- Favicon: downscale the same source to a square `public/favicon.png` with padding, point the
  root route `head().links` icon entry at it, and delete `public/favicon.ico`.
- Verify with a typecheck, the test suite, and a browser pass over the header at mobile and
  desktop widths.

# Chat feedback, steady header, and site links

Three fixes to the chat and footer.

## 1. Make "Helpful / Not helpful" actually do something

Today the two buttons only highlight themselves — nothing is recorded. Change:

- Clicking either button records a private, anonymous feedback note alongside the existing chat activity data (which answer, thumbs up or down, no question or answer text).
- The button stays highlighted and the "Thanks for the feedback." line remains.
- Choosing "Not helpful" also shows a short line offering the two next steps we already support: ask a person for help, or report the answer.
- Feedback counts appear on the Our Impact dashboard as an aggregate "answers rated helpful" figure.

## 2. Keep the Sport Compass banner the same size while it answers

The status pill currently switches from "Ready" to "Working on your answer", which is much wider, so the row of controls rewraps and the whole navy banner grows taller. Change: give the status pill a fixed width and use a short "Working…" label, so the banner never changes size or reflows between idle and answering.

## 3. Site links pointing at the preview address

The footer and menu links are relative, so they follow whatever address the page is open on: on the preview they read as the preview address, and on the published site they read as sports-4-all.org. Nothing is broken there, and I will leave them relative so both keep working.

What is missing is the address search engines and social previews should use. I will add a canonical address and a shareable link address of `https://sports-4-all.org` (plus the matching page path) to every page, so shared and indexed links always point at sports-4-all.org rather than a preview address.

## Technical notes

- Add a `feedback` action to `src/routes/api/sports-for-all-chat.ts` that writes a `chat_events` row (`event_type: "answer_feedback"`, sanitized fields only, existing session token); no new table. Extend `trackEvent`/`ChatEvent` with a `feedback` value if needed.
- `useChat` gains a `sendFeedback(messageId, value)` call; `MessageBubble` calls it. Failures are silent.
- `/api/impact-metrics` aggregates the new event type into a `helpfulRate`; `/impact` scorecard shows it, hidden when there is no data.
- `FencingChat` header: fixed-width status pill (`w-[9.5rem] justify-center` style) with label "Working…" / "Ready"; keep the spinner and `aria-live` wording accessible via `sr-only` full text.
- Add `canonical` link plus `og:url` to each route `head()` using `https://sports-4-all.org` + the route path (leaf routes only, never `__root`).

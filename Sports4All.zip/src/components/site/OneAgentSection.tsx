import { Globe, MessageSquare, Sparkles } from "lucide-react";
import { chatgptPluginUrl } from "@/lib/site/chatgpt";

const CARDS = [
  {
    icon: Globe,
    title: "On Sports-4-All.org",
    body: "Ask questions, explore adaptive fencing, discover programs, and request assistance through the accessible web experience.",
  },
  {
    icon: MessageSquare,
    title: "In ChatGPT",
    body: "Use the Sports 4 All ChatGPT Plugin to access the same Agentforce-powered guidance directly within ChatGPT.",
  },
  {
    icon: Sparkles,
    title: "Powered by Salesforce",
    body: "Agentforce reasons over trusted information, Data Cloud unifies relevant data, and Salesforce workflows support personalized service and human escalation.",
  },
] as const;

export function ChatGptCta({ tone = "light" }: { tone?: "light" | "dark" }) {
  const url = chatgptPluginUrl();
  if (!url) {
    return (
      <p
        className={`inline-flex items-center gap-2 rounded-2xl border px-5 py-3 text-sm font-medium ${
          tone === "dark" ? "border-white/40 text-navy-foreground" : "border-border text-muted-foreground"
        }`}
      >
        <MessageSquare aria-hidden="true" className="size-5 shrink-0" />
        Sports 4 All is also available as a ChatGPT Plugin. Ask the Sports 4 All team for access.
      </p>
    );
  }
  return (
    <a
      href={url}
      target="_blank"
      rel="noreferrer noopener"
      className={`inline-flex min-h-11 items-center gap-2 rounded-full px-6 font-semibold ${
        tone === "dark" ? "bg-gold text-gold-foreground" : "bg-primary text-primary-foreground"
      }`}
    >
      <MessageSquare aria-hidden="true" className="size-5" />
      Try Sports 4 All in ChatGPT
      <span className="sr-only">(opens in a new tab)</span>
    </a>
  );
}

export function OneAgentSection() {
  return (
    <section aria-labelledby="one-agent-heading" className="bg-navy px-4 py-14 text-navy-foreground sm:px-6">
      <div className="mx-auto max-w-7xl">
        <h2 id="one-agent-heading" className="font-display text-2xl font-extrabold sm:text-3xl">
          One Agent. Every Athlete. Every Channel.
        </h2>
        <p className="mt-3 max-w-3xl text-navy-foreground/90">
          Sports should be for everyone. Sports 4 All helps athletes and families understand adaptive sports, discover
          inclusive programs, and get trusted guidance—starting with Fencing for All.
        </p>
        <ul className="mt-8 grid gap-5 md:grid-cols-3">
          {CARDS.map((card) => (
            <li key={card.title} className="rounded-3xl bg-white/10 p-6">
              <card.icon aria-hidden="true" className="size-7 text-gold" />
              <h3 className="mt-3 font-display text-lg font-bold">{card.title}</h3>
              <p className="mt-2 text-navy-foreground/90">{card.body}</p>
            </li>
          ))}
        </ul>
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <ChatGptCta tone="dark" />
        </div>
      </div>
    </section>
  );
}

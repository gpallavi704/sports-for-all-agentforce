import { useAsk } from "@/components/site/ask";

const PATHWAY = [
  "First lesson at a local club",
  "Beginner course and basic footwork",
  "Club bouts and first equipment",
  "Regional competition",
  "National events and classification",
  "International and Paralympic pathway",
];

export function PathwaySection() {
  const ask = useAsk();
  return (
    <section id="pathway" aria-labelledby="pathway-heading" className="bg-navy px-4 py-14 text-navy-foreground sm:px-6">
      <div className="mx-auto max-w-7xl">
        <h2 id="pathway-heading" className="font-display text-2xl font-extrabold sm:text-3xl">
          From First Lesson to the Paralympics
        </h2>
        <ol className="mt-8 grid gap-4 md:grid-cols-3">
          {PATHWAY.map((step, i) => (
            <li key={step} className="rounded-3xl bg-white/10 p-5">
              <p className="font-display text-2xl font-extrabold text-gold">{i + 1}</p>
              <p className="mt-2 font-medium">{step}</p>
            </li>
          ))}
        </ol>
        <p className="mt-6 max-w-3xl text-sm text-navy-foreground/80">
          Pathways vary by country, weapon and classification. Always confirm eligibility, classification and
          qualification requirements with your national governing body.
        </p>
        <button
          type="button"
          onClick={() => ask("How do you qualify for the Paralympics in fencing?")}
          className="mt-6 min-h-11 rounded-full bg-gold px-6 font-semibold text-gold-foreground"
        >
          How do you qualify for the Paralympics?
        </button>
      </div>
    </section>
  );
}

import { useAsk } from "@/components/site/ask";

const WEAPONS = [
  {
    name: "Épée",
    target: "Entire body",
    scoring: "First touch anywhere scores; both can score at once",
    pace: "Patient, precise, tactical",
    appeal: "Simple rules make it a common starting point",
  },
  {
    name: "Foil",
    target: "Torso only",
    scoring: "Right of way decides who scores",
    pace: "Technical, controlled, conversational",
    appeal: "Builds strong fundamentals",
  },
  {
    name: "Sabre",
    target: "Everything above the waist",
    scoring: "Cuts and thrusts, right of way applies",
    pace: "Explosive and fast",
    appeal: "Great for athletes who love speed",
  },
];

export function WeaponsSection() {
  const ask = useAsk();
  return (
    <section id="weapons" aria-labelledby="weapons-heading" className="bg-piste px-4 py-14 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <h2 id="weapons-heading" className="font-display text-2xl font-extrabold sm:text-3xl">
          Foil, épée, and sabre
        </h2>
        <div className="mt-8 overflow-x-auto">
          <table className="w-full min-w-[40rem] border-collapse text-left">
            <caption className="sr-only">Comparison of the three fencing weapons</caption>
            <thead>
              <tr>
                {["Weapon", "Target area", "Scoring concept", "Pace and style", "Beginner appeal"].map((h) => (
                  <th key={h} scope="col" className="border-b border-border py-3 pr-4 font-semibold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {WEAPONS.map((w) => (
                <tr key={w.name}>
                  <th scope="row" className="border-b border-border py-3 pr-4 font-display font-bold">
                    {w.name}
                  </th>
                  <td className="border-b border-border py-3 pr-4">{w.target}</td>
                  <td className="border-b border-border py-3 pr-4">{w.scoring}</td>
                  <td className="border-b border-border py-3 pr-4">{w.pace}</td>
                  <td className="border-b border-border py-3 pr-4">{w.appeal}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <button
          type="button"
          onClick={() => ask("Can a fencer compete in all three weapons?")}
          className="mt-8 min-h-11 rounded-full bg-primary px-6 font-semibold text-primary-foreground"
        >
          Can a fencer compete in all three?
        </button>
      </div>
    </section>
  );
}

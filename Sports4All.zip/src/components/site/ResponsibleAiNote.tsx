import { Link } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";
import { useAsk } from "./ask";

/**
 * Compact, plain-language responsible-AI disclosure shown next to the chat.
 * Every action here is honest: it either navigates to real content or opens a
 * real message to a person. Nothing pretends to be a workflow that doesn't exist.
 */
export function ResponsibleAiNote() {
  const ask = useAsk();
  return (
    <details className="mx-auto mt-6 max-w-4xl rounded-3xl border border-border bg-card p-5">
      <summary className="flex min-h-11 cursor-pointer items-center gap-2 font-semibold">
        <ShieldCheck aria-hidden="true" className="size-5 text-primary" />
        How we use AI responsibly
      </summary>
      <div className="mt-3 space-y-3 text-sm">
        <p>
          Sport Compass is an assistant, not a doctor, coach or referee. It explains how fencing can be adapted and what
          your options are. It never decides whether you can take part, never guesses at a disability, and never gives
          medical advice.
        </p>
        <p>
          Rules about eligibility, classification and Paralympic qualification change over time, so always confirm those
          with the club or governing body. We ask before saving anything about you, and we only ask for the details
          needed to help.
        </p>
        <ul className="flex flex-wrap gap-2 pt-1">
          <li>
            <Link
              to="/impact"
              hash="responsible-ai"
              className="inline-flex min-h-11 items-center rounded-full border border-border px-4 font-medium"
            >
              Why am I seeing this answer?
            </Link>
          </li>
          <li>
            <button
              type="button"
              onClick={() => ask("I'd like someone to help us get started.", "assistance")}
              className="inline-flex min-h-11 items-center rounded-full border border-border px-4 font-medium"
            >
              Ask a person
            </button>
          </li>
          <li>
            <a
              href="mailto:information@usafencing.org?subject=Sport%20Compass%20-%20incorrect%20answer"
              className="inline-flex min-h-11 items-center rounded-full border border-border px-4 font-medium"
            >
              Report an incorrect answer
            </a>
          </li>
        </ul>
      </div>
    </details>
  );
}

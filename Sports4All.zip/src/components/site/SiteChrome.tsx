import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useAsk } from "./ask";
import { AccessibilityWidget } from "./AccessibilityWidget";
import logoAsset from "@/assets/logo-sports-4-all.png.asset.json";

const NAV = [
  { to: "/fencing-for-all", label: "Fencing for All" },
  { to: "/accessibility", label: "Accessibility" },
  { to: "/how-it-works", label: "How It Works" },
  { to: "/impact", label: "Impact" },
] as const;


function Nav() {
  const [open, setOpen] = useState(false);
  const ask = useAsk();
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center">
          <img
            src={logoAsset.url}
            alt="Sports 4 All — Fencing for All"
            className="h-14 w-auto sm:h-20"
          />
        </Link>
        <ul className="ml-auto hidden items-center gap-1 xl:flex">
          {NAV.map((item) => (
            <li key={item.to}>
              <Link
                to={item.to}
                activeProps={{ className: "bg-accent text-accent-foreground" }}
                className="inline-flex min-h-11 items-center rounded-full px-3 font-medium hover:bg-accent hover:text-accent-foreground"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
        <button
          type="button"
          onClick={() => ask()}
          className="ml-auto inline-flex min-h-11 items-center rounded-full bg-primary px-5 font-semibold text-primary-foreground xl:ml-2"
        >
          Ask Sport Compass
        </button>
        <button
          type="button"
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-full border border-border xl:hidden"
        >
          {open ? <X aria-hidden="true" className="size-5" /> : <Menu aria-hidden="true" className="size-5" />}
          <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
        </button>
      </nav>
      {open ? (
        <ul id="mobile-nav" className="border-t border-border px-4 py-2 xl:hidden">
          {NAV.map((item) => (
            <li key={item.to}>
              <Link
                to={item.to}
                onClick={() => setOpen(false)}
                activeProps={{ className: "text-primary" }}
                className="flex min-h-11 items-center border-b border-border/60 font-medium"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      ) : null}
    </header>
  );
}

const FOOTER_GROUPS = [
  {
    title: "Fencing",
    links: [
      { to: "/fencing-for-all", label: "Fencing for All" },
      { to: "/fencing-for-all", label: "Explore Fencing", hash: "weapons" },
      { to: "/fencing-for-all", label: "Paralympic Pathway", hash: "pathway" },
    ],
  },
  {
    title: "Sports 4 All",
    links: [
      { to: "/impact", label: "Impact" },
      { to: "/how-it-works", label: "How It Works" },
    ],
  },
  {
    title: "Accessibility",
    links: [
      { to: "/accessibility", label: "Accessibility" },
      { to: "/accessibility", label: "Accessibility Statement", hash: "accessibility" },
    ],
  },
] as const;


function Footer() {
  return (
    <footer className="border-t border-border bg-card px-4 py-12 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-8 sm:grid-cols-3">
          {FOOTER_GROUPS.map((group) => (
            <nav key={group.title} aria-label={group.title}>
              <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">{group.title}</h2>
              <ul className="mt-1">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      {...("hash" in link ? { hash: link.hash } : {})}
                      className="inline-flex min-h-11 items-center font-medium hover:underline hover:underline-offset-4"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
                {group.title === "Accessibility" ? (
                  <li>
                    <button
                      type="button"
                      onClick={() => window.dispatchEvent(new CustomEvent("s4a:a11y-open"))}
                      className="inline-flex min-h-11 items-center font-medium hover:underline hover:underline-offset-4"
                    >
                      Accessibility options
                    </button>
                  </li>
                ) : null}
              </ul>
            </nav>
          ))}
        </div>
        <p className="mt-8 border-t border-border pt-6 text-sm text-muted-foreground">Powered by Salesforce Agentforce + Data Cloud</p>
        <p className="mt-3 max-w-3xl text-sm text-muted-foreground">
          Sport Compass provides educational guidance only. It does not provide medical advice and does not make
          eligibility, classification, selection, qualification or accommodation decisions. Always confirm details with
          clubs, programs and governing organizations.
        </p>
      </div>
    </footer>
  );
}

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (pathname.startsWith("/api/")) return <>{children}</>;
  return (
    <div className="min-h-dvh bg-background">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-primary focus:px-5 focus:py-3 focus:text-primary-foreground"
      >
        Skip to main content
      </a>
      <Nav />
      <main id="main">{children}</main>
      <Footer />
      <AccessibilityWidget />
    </div>
  );
}

import { useEffect, useState } from "react";
import { CheckCircle2, CircleDashed, Loader2, PlayCircle } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useAsk } from "@/components/site/ask";
import { ChatGptCta } from "@/components/site/OneAgentSection";
import type { ImpactMetrics, ImpactStatus } from "@/routes/api/impact-metrics";
import type { ChatTool } from "@/lib/chat/routing";

/* ---------------------------------------------------------------- helpers */

function Section({
  id,
  eyebrow,
  heading,
  children,
  tone = "default",
}: {
  id: string;
  eyebrow?: string;
  heading: string;
  children: React.ReactNode;
  tone?: "default" | "muted" | "navy";
}) {
  const bg =
    tone === "navy" ? "bg-navy text-navy-foreground" : tone === "muted" ? "bg-piste" : "bg-background";
  return (
    <section id={id} aria-labelledby={`${id}-heading`} className={`${bg} px-4 py-14 sm:px-6`}>
      <div className="mx-auto max-w-6xl">
        {eyebrow ? (
          <p className={`text-sm font-semibold uppercase tracking-wide ${tone === "navy" ? "text-gold" : "text-primary"}`}>
            {eyebrow}
          </p>
        ) : null}
        <h2 id={`${id}-heading`} className="mt-2 font-display text-2xl font-extrabold sm:text-3xl">
          {heading}
        </h2>
        <div className="mt-6 space-y-6">{children}</div>
      </div>
    </section>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
      <h3 className="font-display text-lg font-bold">{title}</h3>
      <div className="mt-2 text-muted-foreground">{children}</div>
    </div>
  );
}

type Maturity = "Live" | "Prototype" | "Next";

function MaturityTag({ level }: { level: Maturity }) {
  const styles: Record<Maturity, string> = {
    Live: "border-primary bg-primary/10 text-primary",
    Prototype: "border-gold bg-gold/15 text-navy",
    Next: "border-border bg-muted text-foreground",
  };
  const mark: Record<Maturity, string> = { Live: "●", Prototype: "◐", Next: "○" };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-bold ${styles[level]}`}>
      <span aria-hidden="true">{mark[level]}</span>
      {level}
    </span>
  );
}

function Bullets({ items }: { items: readonly string[] }) {
  return (
    <ul className="ml-5 list-disc space-y-2">
      {items.map((item) => (
        <li key={item}>{item}</li>
      ))}
    </ul>
  );
}

/* ------------------------------------------------------------- section 1 */

const JOURNEY = [
  "Ask a question",
  "Understand available adaptations",
  "Find a suitable program",
  "Save relevant preferences with consent",
  "Connect with a person when needed",
  "Begin participating",
] as const;

function Challenge() {
  return (
    <Section
      id="challenge"
      eyebrow="The challenge"
      heading="The opportunity to participate exists. Finding it is the hard part."
      tone="muted"
    >
      <Bullets
        items={[
          "Families often do not know whether a sport can accommodate a disability.",
          "Adaptive-sports information is scattered across governing bodies, clubs, events and local organizations.",
          "Rules, classification, equipment and qualification pathways are confusing, and many families do not know what to ask.",
          "Program details are often outdated, inaccessible, or unavailable in the family's language.",
          "Smaller organizations cannot answer questions around the clock, so people give up rather than ask for help.",
        ]}
      />
      <div>
        <h3 className="font-display text-lg font-bold">From uncertainty to participation</h3>
        <ol className="mt-4 grid gap-3 md:grid-cols-3">
          {JOURNEY.map((step, index) => (
            <li key={step} className="flex items-start gap-3 rounded-2xl border border-border bg-card p-4">
              <span
                aria-hidden="true"
                className="mt-0.5 inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground"
              >
                {index + 1}
              </span>
              <span className="font-medium">
                <span className="sr-only">Step {index + 1}: </span>
                {step}
              </span>
            </li>
          ))}
        </ol>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 2 */

const AUDIENCES = [
  "Children and adults with disabilities",
  "Parents and caregivers",
  "Beginning athletes",
  "Adaptive and wheelchair athletes",
  "Coaches and club operators",
  "Families who speak different languages",
  "People who do not know which sport or program fits their needs",
] as const;

const IMPACT_MEASURES: ReadonlyArray<{ label: string; kind: "Pilot target" | "Live measurement" | "Demonstration data"; note: string }> = [
  { label: "Time needed to find an appropriate program", kind: "Pilot target", note: "Reduce from days of searching to a single conversation." },
  { label: "Successful program referrals", kind: "Pilot target", note: "Increase referrals that end with a named club or program." },
  { label: "Access to multilingual guidance", kind: "Pilot target", note: "Answer in the family's preferred language." },
  { label: "Repetitive administrative questions", kind: "Pilot target", note: "Reduce the load on small sports organizations." },
  { label: "Conversations ending in a useful next step", kind: "Pilot target", note: "Every conversation should leave someone with something to do next." },
  { label: "Reaching a human when automation is not enough", kind: "Live measurement", note: "Human assistance is available in every conversation today." },
];

function SocialImpact() {
  return (
    <Section id="social-impact" eyebrow="Social impact and ethical focus" heading="Removing barriers between curiosity and participation">
      <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {AUDIENCES.map((a) => (
          <li key={a} className="rounded-2xl border border-border bg-card p-4 font-medium">
            {a}
          </li>
        ))}
      </ul>
      <p>
        The agent does not decide whether someone is capable of participating. It helps people understand options,
        accommodations, programs and appropriate next steps.
      </p>
      <p className="rounded-3xl bg-navy p-6 font-display text-xl font-extrabold text-navy-foreground sm:text-2xl">
        The agent opens doors. It does not define a person&rsquo;s limits.
      </p>
      <div>
        <h3 className="font-display text-lg font-bold">Impact measures</h3>
        <p className="mt-1 text-muted-foreground">
          Every measure below is labelled honestly. Nothing here is a claimed result.
        </p>
        <ul className="mt-4 grid gap-3 md:grid-cols-2">
          {IMPACT_MEASURES.map((m) => (
            <li key={m.label} className="rounded-2xl border border-border bg-card p-5">
              <span className="inline-flex rounded-full border border-border bg-muted px-3 py-1 text-xs font-bold">
                {m.kind}
              </span>
              <h4 className="mt-2 font-semibold">{m.label}</h4>
              <p className="mt-1 text-muted-foreground">{m.note}</p>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 3 */

function ResponsibleAi() {
  return (
    <Section id="responsible-ai" eyebrow="Responsible AI" heading="Helpful AI with human-centered guardrails" tone="muted">
      <Bullets
        items={[
          "Sport Compass never diagnoses, infers a disability, or tells someone they cannot participate.",
          "It separates general guidance from official eligibility, classification and qualification rules, and treats those rules as time-sensitive.",
          "It points to the governing body or a qualified professional whenever confirmation is needed, or confidence is limited.",
          "It asks for consent before saving preferences, and for confirmation before sending contact details.",
          "It collects only the minimum information needed.",
          "Agentforce credentials, Salesforce tokens, internal prompts and raw error details never reach the browser.",
          "A clear path to human assistance is available in every conversation.",
        ]}
      />
      <p>
        Accessibility is part of the same commitment.{" "}
        <Link to="/accessibility" hash="accessibility" className="font-semibold text-primary underline underline-offset-4">
          Read the accessibility commitment and statement
        </Link>
        .
      </p>
    </Section>
  );
}

/* ------------------------------------------------------------- section 4 */

export function AccessibilitySection() {
  return (
    <Section id="accessibility" heading="Accessibility is the product, not an add-on">
      <p>
        The whole site — not just this page — is designed toward WCAG 2.2 AA. Accessibility work here is deliberate and
        tested by keyboard, at 200% zoom and with reduced motion enabled.
      </p>
      <div className="grid gap-5 md:grid-cols-2">
        <Card title="Built in throughout">
          <Bullets
            items={[
              "Full keyboard navigation with visible focus indicators",
              "Skip-to-content link, semantic landmarks and ordered headings",
              "Labelled controls, instructions and accessible form validation",
              "Chat responses announced politely to screen readers",
              "Accessible loading and error states, never colour alone",
              "AA colour contrast, large touch targets, plain language",
              "Browser zoom and text resizing supported",
              "Reduced-motion support and no auto-playing animation",
              "Descriptive alternative text; decorative images hidden",
              "Language attributes set when the answer language changes",
              "Responsive layouts for phone, tablet, laptop and widescreen",
            ]}
          />
        </Card>
        <Card title="Accessibility preferences">
          <p>
            The accessibility button in the bottom corner of every page lets anyone set larger text, increased contrast,
            reduced motion, a more spacious layout, underlined links and a more readable typeface. Preferences are saved
            in your browser — no account needed.
          </p>
          <button
            type="button"
            onClick={() => window.dispatchEvent(new CustomEvent("s4a:a11y-open"))}
            className="mt-4 inline-flex min-h-11 items-center rounded-full bg-primary px-5 font-semibold text-primary-foreground"
          >
            Open accessibility options
          </button>
        </Card>
      </div>
      <div className="rounded-3xl border border-border bg-card p-6">
        <h3 className="font-display text-lg font-bold">Accessibility statement</h3>
        <dl className="mt-3 space-y-3">
          <div>
            <dt className="font-semibold">Our target</dt>
            <dd className="text-muted-foreground">
              Designed toward WCAG 2.2 AA. We do not claim full conformance, because not every page has been formally
              audited by an independent tester.
            </dd>
          </div>
          <div>
            <dt className="font-semibold">Supported features</dt>
            <dd className="text-muted-foreground">
              Keyboard-only use, screen-reader labelling and live announcements in chat, visible focus, reduced motion,
              text resizing to 200%, adjustable text size, contrast, spacing and typeface.
            </dd>
          </div>
          <div>
            <dt className="font-semibold">Known limitations</dt>
            <dd className="text-muted-foreground">
              Answers come from an AI agent, so response wording varies and may occasionally be long. Program
              information depends on the governing body and may be incomplete. Some content is currently English only.
            </dd>
          </div>
          <div>
            <dt className="font-semibold">Reporting a problem</dt>
            <dd className="text-muted-foreground">
              Email{" "}
              <a
                className="underline underline-offset-4"
                href="mailto:information@usafencing.org?subject=Accessibility%20feedback"
              >
                information@usafencing.org
              </a>{" "}
              and tell us the page and what got in your way. We aim to reply within five working days.
            </dd>
          </div>
        </dl>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 5 */

const ARCHITECTURE = [
  { label: "Athlete or family", detail: "A real question, in plain language." },
  { label: "Sports-4-All.org or ChatGPT Plugin", detail: "The channel the person already prefers." },
  { label: "Sports 4 All MCP", detail: "A secure, reusable tool interface. Credentials stay on the server." },
  { label: "Salesforce Agentforce", detail: "Reasoning, tool choice, grounded answers, conversational continuity." },
  {
    label: "Data Cloud, trusted sports information, program data and Salesforce workflows",
    detail: "Grounding, unified records and human escalation.",
  },
] as const;

function Originality() {
  return (
    <Section id="originality" eyebrow="Originality" heading="A trusted sports-access agent that can go anywhere" tone="muted">
      <Bullets
        items={[
          "The experience begins with the human question, not a complicated directory.",
          "Agentforce turns uncertainty into clear next steps, and human escalation stays part of the journey.",
          "Data Cloud can unify program, governing-body, participant-preference and engagement data.",
          "MCP makes the same governed agent reusable across the website, the ChatGPT Plugin and future channels.",
          "Fencing is the focused start; the architecture expands to other summer, winter, recreational and Paralympic sports.",
        ]}
      />
      <div>
        <h3 className="font-display text-lg font-bold">How a question travels</h3>
        <p className="mt-1 text-muted-foreground">
          Text description: a question from an athlete or family enters through the website or the ChatGPT Plugin, is
          passed to the Sports 4 All MCP, which calls Salesforce Agentforce, which draws on Data Cloud, trusted sports
          information, program data and Salesforce workflows before answering back along the same path.
        </p>
        <ol className="mt-4 space-y-2">
          {ARCHITECTURE.map((layer, index) => (
            <li key={layer.label}>
              <div className="rounded-2xl border border-border bg-card p-5">
                <p className="font-display font-bold">{layer.label}</p>
                <p className="text-muted-foreground">{layer.detail}</p>
              </div>
              {index < ARCHITECTURE.length - 1 ? (
                <p aria-hidden="true" className="py-1 text-center text-2xl text-primary">
                  ↓
                </p>
              ) : null}
            </li>
          ))}
        </ol>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 6 */

const SCENARIOS: ReadonlyArray<{
  title: string;
  question: string;
  intent?: ChatTool;
  expectations: readonly string[];
}> = [
  {
    title: "Scenario 1: Inclusive participation",
    question: "Can my daughter fence from a wheelchair?",
    expectations: [
      "Calls ask_fencing_question",
      "Gives encouraging, practical guidance",
      "Avoids medical assumptions",
      "Suggests an appropriate next step",
    ],
  },
  {
    title: "Scenario 2: Fencing education",
    question: "What's the difference between épée, foil, and sabre? Can someone do all three?",
    expectations: [
      "Calls ask_fencing_question",
      "Clearly explains the three disciplines",
      "Supports a follow-up in the same Agentforce session",
    ],
  },
  {
    title: "Scenario 3: Paralympic pathway",
    question: "How do you qualify for the Paralympics?",
    expectations: [
      "Calls ask_fencing_question",
      "Explains the general pathway",
      "Flags rules as time-sensitive",
      "Recommends official confirmation",
    ],
  },
  {
    title: "Scenario 4: Program discovery",
    question: "Find an inclusive fencing program near me.",
    expectations: [
      "Asks for location only when needed",
      "Calls find_sports_programs",
      "Uses get_program_details after you choose a result",
      "Presents accessible, scannable result cards",
    ],
  },
  {
    title: "Scenario 5: Human assistance",
    question: "I'd like someone to help us get started.",
    intent: "request_human_assistance",
    expectations: [
      "Explains what will be submitted",
      "Asks for your confirmation",
      "Calls request_human_assistance",
      "Shows a clear success or retry state",
    ],
  },
];

const STATUS_LABEL: Record<string, string> = {
  ready: "Ready",
  connected: "Connected",
  available: "Available",
  mock: "Demonstration mode",
  coming_online: "Coming online",
  unavailable: "Unavailable",
};

function StatusRow({ label, value }: { label: string; value: string }) {
  const good = ["ready", "connected", "available"].includes(value);
  const Icon = good ? CheckCircle2 : CircleDashed;
  return (
    <li className="flex items-center justify-between gap-3 border-b border-border py-3 last:border-b-0">
      <span className="font-medium">{label}</span>
      <span className={`inline-flex items-center gap-2 font-semibold ${good ? "text-primary" : "text-muted-foreground"}`}>
        <Icon aria-hidden="true" className="size-5" />
        {STATUS_LABEL[value] ?? value}
      </span>
    </li>
  );
}

function Demonstrability({
  status,
  loading,
}: {
  status: ImpactStatus | null;
  loading: boolean;
}) {
  const ask = useAsk();
  return (
    <Section id="demo" eyebrow="Try it" heading="Try the complete journey">
      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <ul className="space-y-4">
          {SCENARIOS.map((s) => (
            <li key={s.title} className="rounded-3xl border border-border bg-card p-6">
              <h3 className="font-display text-lg font-bold">{s.title}</h3>
              <p className="mt-1 italic">&ldquo;{s.question}&rdquo;</p>
              <ul className="mt-3 ml-5 list-disc text-muted-foreground">
                {s.expectations.map((e) => (
                  <li key={e}>{e}</li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => ask(s.question, s.intent)}
                className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 font-semibold text-primary-foreground"
              >
                <PlayCircle aria-hidden="true" className="size-5" />
                Run this scenario
              </button>
            </li>
          ))}
        </ul>
        <div className="h-fit rounded-3xl border border-border bg-card p-6">
          <h3 className="font-display text-lg font-bold">Live system status</h3>
          {loading ? (
            <p className="mt-3 flex items-center gap-2 text-muted-foreground">
              <Loader2 aria-hidden="true" className="size-4 animate-spin" />
              Checking services…
            </p>
          ) : status ? (
            <ul className="mt-3" aria-label="Live system status">
              <StatusRow label="Web experience" value={status.web} />
              <StatusRow label="Sports 4 All MCP" value={status.mcp} />
              <StatusRow label="Agentforce" value={status.agentforce} />
              <StatusRow label="ChatGPT Plugin" value={status.chatgptPlugin} />
              <StatusRow label="Ask for a person" value={status.humanEscalation} />
            </ul>
          ) : (
            <p className="mt-3 text-muted-foreground">Status could not be checked right now.</p>
          )}
          <p className="mt-4 text-sm text-muted-foreground">
            Each status is checked against the live service. Nothing here is hard-coded.
          </p>
          <p className="mt-3 text-sm text-muted-foreground">
            <strong className="font-semibold text-foreground">Ask for a person</strong> means a visitor can always
            reach a human. When someone asks for help, Sport Compass shows a short form, asks permission before
            sending anything, and passes the name, preferred contact method and reason to USA Fencing at
            information@usafencing.org. This status shows whether that request tool is reachable right now — never
            that a person is waiting live.
          </p>
        </div>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 7 */

const PHASES = [
  {
    title: "Phase 1: Fencing for All",
    level: "Live" as Maturity,
    items: [
      "Wheelchair and adaptive fencing education",
      "USA Fencing information",
      "Program discovery",
      "Human assistance",
      "Web and ChatGPT access",
    ],
  },
  {
    title: "Phase 2: More adaptive sports",
    level: "Next" as Maturity,
    items: [
      "Summer and winter sports",
      "Local and national programs",
      "Governing-body information",
      "Event and clinic discovery",
    ],
  },
  {
    title: "Phase 3: A reusable platform",
    level: "Next" as Maturity,
    items: [
      "Sports organizations onboard their own trusted data",
      "Shared Agentforce and MCP architecture",
      "Multilingual support",
      "Additional consumer channels",
      "Aggregate analytics that reveal where people encounter barriers",
    ],
  },
] as const;

function Scalability() {
  return (
    <Section id="scale" eyebrow="Scalability and adoption" heading="Start with fencing. Scale to every sport." tone="muted">
      <ol className="grid gap-5 md:grid-cols-3">
        {PHASES.map((phase) => (
          <li key={phase.title} className="rounded-3xl border border-border bg-card p-6">
            <MaturityTag level={phase.level} />
            <h3 className="mt-3 font-display text-lg font-bold">{phase.title}</h3>
            <ul className="mt-2 ml-5 list-disc text-muted-foreground">
              {phase.items.map((i) => (
                <li key={i}>{i}</li>
              ))}
            </ul>
          </li>
        ))}
      </ol>
      <div>
        <h3 className="font-display text-lg font-bold">The adoption model</h3>
        <Bullets
          items={[
            "Governing bodies contribute verified information; clubs keep availability and accessibility details current.",
            "Athletes and families use the channel they already prefer.",
            "Agentforce answers common questions and escalates higher-touch needs.",
            "Data Cloud helps unify fragmented information and measure unmet demand.",
          ]}
        />
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 8 */

const PROOF: ReadonlyArray<{ title: string; rows: ReadonlyArray<[string, Maturity]> }> = [
  {
    title: "What Agentforce does",
    rows: [
      ["Interprets natural-language questions", "Live"],
      ["Chooses the appropriate action", "Live"],
      ["Retrieves grounded information", "Live"],
      ["Maintains conversational continuity", "Live"],
      ["Returns helpful next steps", "Live"],
      ["Escalates to a human when necessary", "Prototype"],
    ],
  },
  {
    title: "What Data Cloud does",
    rows: [
      ["Unifies program and organization records", "Prototype"],
      ["Supports grounding with trusted information", "Prototype"],
      ["Connects participant preferences only with consent", "Prototype"],
      ["Aggregate insight into topics, locations, languages and unmet needs", "Next"],
      ["Helps organizations spot missing accessibility information", "Next"],
    ],
  },
  {
    title: "What the MCP layer does",
    rows: [
      ["Provides a secure, reusable interface to Agentforce", "Live"],
      ["Keeps Salesforce credentials on the server", "Live"],
      ["Supports the consumer website", "Live"],
      ["Supports the ChatGPT Plugin", "Live"],
      ["Allows additional channels to use the same governed agent", "Next"],
    ],
  },
];

function AgentforceProof() {
  return (
    <Section id="agentforce" eyebrow="Under the hood" heading="Built on Agentforce—not merely branded with AI">
      <div className="grid gap-5 md:grid-cols-3">
        {PROOF.map((group) => (
          <div key={group.title} className="rounded-3xl border border-border bg-card p-6">
            <h3 className="font-display text-lg font-bold">{group.title}</h3>
            <ul className="mt-3 space-y-3">
              {group.rows.map(([label, level]) => (
                <li key={label} className="flex flex-wrap items-center gap-2">
                  <MaturityTag level={level} />
                  <span>{label}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------- section 9 */

function HeadlessSection() {
  return (
    <Section id="headless" eyebrow="Headless Hero" heading="Agentforce beyond the website" tone="navy">
      <p className="max-w-3xl text-navy-foreground/90">
        Sports 4 All is also available through a ChatGPT Plugin powered by the same Agentforce agent and MCP tools. This
        demonstrates a headless Agentforce architecture: one governed agent, reusable across multiple consumer
        experiences.
      </p>
      <ChatGptCta tone="dark" />
      <dl className="grid gap-5 md:grid-cols-3">
        <div className="rounded-3xl bg-white/10 p-6">
          <dt className="font-display text-lg font-bold">Website</dt>
          <dd className="mt-2 text-navy-foreground/90">Visual discovery, guided examples, accessible program cards.</dd>
        </div>
        <div className="rounded-3xl bg-white/10 p-6">
          <dt className="font-display text-lg font-bold">ChatGPT Plugin</dt>
          <dd className="mt-2 text-navy-foreground/90">Conversational access in a familiar AI workspace.</dd>
        </div>
        <div className="rounded-3xl bg-white/10 p-6">
          <dt className="font-display text-lg font-bold">Shared foundation</dt>
          <dd className="mt-2 text-navy-foreground/90">
            Agentforce, Data Cloud, MCP tools, safeguards and human escalation.
          </dd>
        </div>
      </dl>
    </Section>
  );
}

/* ------------------------------------------------------------ section 10 */

function Observability({ metrics, loading }: { metrics: ImpactMetrics | null; loading: boolean }) {
  const tiles: ReadonlyArray<[string, string]> = metrics
    ? [
        ["Demo conversations", String(metrics.conversations)],
        ["Successful MCP tool calls", String(metrics.toolCalls)],
        ["Questions answered", String(metrics.questionsAnswered)],
        ["Programs surfaced", String(metrics.programsSurfaced)],
        ["Human handoffs requested", String(metrics.humanHandoffs)],
        ["Languages used", String(metrics.languages)],
        ["Median response time", metrics.medianResponseMs ? `${(metrics.medianResponseMs / 1000).toFixed(1)}s` : "—"],
        ["Tool success rate", metrics.toolSuccessRate === null ? "—" : `${metrics.toolSuccessRate}%`],
        [
          "Answers rated helpful",
          metrics.helpfulRate === null ? "—" : `${metrics.helpfulRate}% of ${metrics.answersRated}`,
        ],
      ]
    : [];
  return (
    <Section
      id="observability"
      eyebrow="Agent observability"
      heading="Every agent action should be understandable and measurable"
      tone="muted"
    >
      <div className="grid gap-5 md:grid-cols-2">
        <Card title="What we record">
          <Bullets
            items={[
              "Agent sessions: internal id, hashed visitor token, Agentforce session id, sequence id, channel, language, timestamps and consent state.",
              "Agent events: session reference, timestamp, tool name, event type, success or failure, response latency, error category, escalation requested, program result count and safety fallback.",
            ]}
          />
        </Card>
        <Card title="What we never record">
          <Bullets
            items={[
              "Salesforce access tokens, Agentforce credentials or MCP secrets.",
              "Medical details or full contact information in analytics.",
              "Raw conversations — transcripts are not stored by default.",
              "Administrative data exposed to the browser: this dashboard is aggregate-only, served from the server under row-level security.",
            ]}
          />
        </Card>
      </div>
      <div>
        <h3 className="font-display text-lg font-bold">Judge dashboard</h3>
        {loading ? (
          <p className="mt-3 flex items-center gap-2 text-muted-foreground">
            <Loader2 aria-hidden="true" className="size-4 animate-spin" />
            Loading measurements…
          </p>
        ) : metrics && metrics.hasData ? (
          <dl className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {tiles.map(([label, value]) => (
              <div key={label} className="rounded-3xl border border-border bg-card p-5">
                <dt className="text-sm font-medium text-muted-foreground">{label}</dt>
                <dd className="mt-1 font-display text-3xl font-extrabold">{value}</dd>
              </div>
            ))}
          </dl>
        ) : (
          <p className="mt-3 rounded-3xl border border-dashed border-border bg-card p-6 text-muted-foreground">
            No conversations have been recorded yet. Run a demo scenario above and these measurements will fill in with
            real activity — we do not display sample numbers.
          </p>
        )}
        <p className="mt-3 text-sm text-muted-foreground">
          Live measurement. Aggregate counts only; no question or answer text is ever shown here.
        </p>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ page */

export function ImpactSections() {
  const [status, setStatus] = useState<ImpactStatus | null>(null);
  const [metrics, setMetrics] = useState<ImpactMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    void fetch("/api/impact-metrics", { headers: { Accept: "application/json" } })
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { status: ImpactStatus; metrics: ImpactMetrics } | null) => {
        if (!active || !data) return;
        setStatus(data.status);
        setMetrics(data.metrics);
      })
      .catch(() => undefined)
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <>
      <Challenge />
      <SocialImpact />
      <ResponsibleAi />
      <Originality />
      <Demonstrability status={status} loading={loading} />
      <Scalability />
      <AgentforceProof />
      <HeadlessSection />
      <Observability metrics={metrics} loading={loading} />
    </>
  );
}

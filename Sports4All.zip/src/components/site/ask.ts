import { useNavigate } from "@tanstack/react-router";

/**
 * Sends a question to Sport Compass. When the chat card is already on the
 * page it is submitted in place; otherwise the visitor is taken to /ask
 * with the question, which is submitted on arrival.
 */
export function useAsk() {
  const navigate = useNavigate();
  return (question?: string, intent?: string) => {
    if (typeof document !== "undefined" && document.getElementById("chat")) {
      window.dispatchEvent(new CustomEvent("s4a:ask", { detail: { question, intent } }));
      return;
    }
    void navigate({
      to: "/ask",
      search: { ...(question ? { q: question } : {}), ...(intent ? { intent } : {}) },
    });
  };
}

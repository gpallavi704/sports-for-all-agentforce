import { useCallback, useEffect, useRef, useState } from "react";
import { Accessibility, X } from "lucide-react";

type Prefs = {
  text: "normal" | "lg" | "xl";
  contrast: boolean;
  motion: boolean;
  links: boolean;
  font: boolean;
  space: boolean;
};

const DEFAULTS: Prefs = { text: "normal", contrast: false, motion: false, links: false, font: false, space: false };
const KEY = "s4a_a11y";

function apply(prefs: Prefs) {
  const el = document.documentElement;
  el.setAttribute("data-a11y-text", prefs.text);
  el.setAttribute("data-a11y-contrast", prefs.contrast ? "high" : "normal");
  el.setAttribute("data-a11y-motion", prefs.motion ? "reduce" : "auto");
  el.setAttribute("data-a11y-links", prefs.links ? "underline" : "auto");
  el.setAttribute("data-a11y-font", prefs.font ? "readable" : "auto");
  el.setAttribute("data-a11y-space", prefs.space ? "roomy" : "auto");
}

export function AccessibilityWidget() {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) {
        const parsed = { ...DEFAULTS, ...(JSON.parse(raw) as Partial<Prefs>) };
        setPrefs(parsed);
        apply(parsed);
      }
    } catch {
      /* ignore unreadable storage */
    }
    setReady(true);
  }, []);

  const update = useCallback((patch: Partial<Prefs>) => {
    setPrefs((current) => {
      const next = { ...current, ...patch };
      apply(next);
      try {
        window.localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* ignore unwritable storage */
      }
      return next;
    });
  }, []);

  useEffect(() => {
    function onOpen() {
      setOpen(true);
    }
    window.addEventListener("s4a:a11y-open", onOpen);
    return () => window.removeEventListener("s4a:a11y-open", onOpen);
  }, []);

  useEffect(() => {
    if (!open) return;
    const panel = panelRef.current;
    panel?.querySelector<HTMLElement>("button, [href], input, select")?.focus();

    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
        return;
      }
      if (e.key !== "Tab" || !panelRef.current) return;
      const items = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>('button, [href], input:not([disabled])'),
      ).filter((el) => el.offsetParent !== null);
      if (items.length === 0) return;
      const first = items[0]!;
      const last = items[items.length - 1]!;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  if (!ready) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 print:hidden">
      {open ? (
        <div
          ref={panelRef}
          role="dialog"
          aria-modal="false"
          aria-label="Accessibility options"
          className="mb-3 w-[19rem] rounded-3xl border border-border bg-card p-5 shadow-2xl"
        >
          <div className="flex items-start justify-between gap-3">
            <h2 className="font-display text-lg font-bold">Accessibility options</h2>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                buttonRef.current?.focus();
              }}
              aria-label="Close accessibility options"
              className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-full hover:bg-accent"
            >
              <X aria-hidden="true" className="size-5" />
            </button>
          </div>

          <fieldset className="mt-4">
            <legend className="text-sm font-semibold">Text size</legend>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {(
                [
                  ["normal", "Normal"],
                  ["lg", "Large"],
                  ["xl", "Extra large"],
                ] as const
              ).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  aria-pressed={prefs.text === value}
                  onClick={() => update({ text: value })}
                  className={`min-h-11 rounded-xl border px-2 text-sm font-medium ${
                    prefs.text === value
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-background"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </fieldset>

          <ul className="mt-4 space-y-1">
            {(
              [
                ["contrast", "High contrast"],
                ["space", "More spacious layout"],
                ["motion", "Reduce motion"],
                ["links", "Underline links"],
                ["font", "Readable font"],
              ] as const
            ).map(([key, label]) => (
              <li key={key}>
                <label className="flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-xl px-2 hover:bg-accent">
                  <span className="text-sm font-medium">{label}</span>
                  <input
                    type="checkbox"
                    checked={prefs[key]}
                    onChange={(e) => update({ [key]: e.target.checked } as Partial<Prefs>)}
                    className="size-5 accent-[color:var(--color-primary)]"
                  />
                </label>
              </li>
            ))}
          </ul>

          <button
            type="button"
            onClick={() => {
              apply(DEFAULTS);
              setPrefs(DEFAULTS);
              try {
                window.localStorage.removeItem(KEY);
              } catch {
                /* ignore */
              }
            }}
            className="mt-4 min-h-11 w-full rounded-full border border-border font-semibold"
          >
            Reset all
          </button>
        </div>
      ) : null}

      <button
        ref={buttonRef}
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label="Accessibility options"
        className="ml-auto flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-xl"
      >
        <Accessibility aria-hidden="true" className="size-6" />
      </button>
    </div>
  );
}

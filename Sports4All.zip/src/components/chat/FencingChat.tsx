import { useCallback, useEffect, useRef, useState } from "react";
import { Check, Copy, Loader2, MapPin, Maximize2, RefreshCw, Send, ShieldCheck, ThumbsDown, ThumbsUp, X } from "lucide-react";
import { useChat, type ChatMessage } from "./useChat";
import { parseTool } from "@/lib/chat/routing";
import { isYesNoQuestion } from "@/lib/chat/quick-replies";
import { emailError, phoneError } from "@/lib/chat/contact";
import agentAvatar from "@/assets/sport-compass-avatar.png.asset.json";

const EXAMPLES = [
  "Can my daughter fence from a wheelchair?",
  "What’s the difference between épée, foil, and sabre?",
  "Can a fencer compete in all three?",
  "How do you qualify for the Paralympics?",
  "What equipment does a beginner need?",
  "Can you help me find an accessible fencing club?",
  "At what age can someone start fencing?",
  "Are scholarships or financial assistance available?",
];

const WELCOME =
  "Hi! I’m Sport Compass, powered by Agentforce. I can help you explore fencing, understand adaptive options, find programs, and request additional assistance. What would you like to know?";

const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "es", label: "Español" },
  { code: "fr", label: "Français" },
];

const MAX_CHARS = 1500;

function AgentAvatar({ size = 40 }: { size?: number }) {
  return (
    <img
      aria-hidden="true"
      alt=""
      src={agentAvatar.url}
      width={size}
      height={size}
      className="shrink-0 rounded-full object-cover ring-2 ring-primary/30"
      style={{ width: size, height: size }}
    />
  );
}

const LOCATION_PROMPT =
  /(zip|postal code|what city|which city|where are you|where do you live|your city|your area|nearest city|city or town|location)/i;

/** Asks the browser for coarse coordinates and converts them to a place name. */
async function resolvePlace(): Promise<string | null> {
  if (typeof navigator === "undefined" || !navigator.geolocation || !window.isSecureContext) return null;
  const pos = await new Promise<GeolocationPosition | null>((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (p) => resolve(p),
      () => resolve(null),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 },
    );
  });
  if (!pos) return null;
  try {
    const res = await fetch("/api/reverse-geocode", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        lat: Number(pos.coords.latitude.toFixed(2)),
        lng: Number(pos.coords.longitude.toFixed(2)),
      }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { place?: string | null };
    return data.place ?? null;
  } catch {
    return null;
  }
}

function MessageBubble({
  message,
  isLatest,
  onFollowUp,
  onFeedback,
  onAskPerson,
  onShareLocation,
}: {
  message: ChatMessage;
  isLatest: boolean;
  onFollowUp: (q: string) => void;
  onFeedback: (value: "up" | "down") => void;
  onAskPerson: () => void;
  onShareLocation: (place: string) => void;
}) {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<"up" | "down" | null>(null);
  const [locState, setLocState] = useState<"idle" | "busy" | "error">("idle");

  async function shareLocation() {
    setLocState("busy");
    const place = await resolvePlace();
    if (!place) {
      setLocState("error");
      return;
    }
    setLocState("idle");
    onShareLocation(place);
  }

  function rate(value: "up" | "down") {
    if (feedback === value) return;
    setFeedback(value);
    onFeedback(value);
  }

  const isUser = message.role === "user";

  if (isUser) {
    return (
      <li className="flex justify-end">
        <div className="max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-3 text-primary-foreground shadow-sm">
          <p className="whitespace-pre-wrap break-words">{message.text}</p>
          <p className="mt-1 text-xs text-primary-foreground/80">
            {message.state === "error" ? "Not delivered" : message.state === "sending" ? "Sending…" : "Sent"}
          </p>
        </div>
      </li>
    );
  }

  return (
    <li className="flex gap-3">
      <AgentAvatar size={36} />
      <div className="max-w-[88%] flex-1">
        <div className="rounded-2xl rounded-bl-md border border-border bg-piste px-4 py-3 text-card-foreground shadow-sm">
          {message.text.split(/\n{2,}/).map((para, i) => (
            <p key={i} className={i > 0 ? "mt-3 whitespace-pre-wrap break-words" : "whitespace-pre-wrap break-words"}>
              {para}
            </p>
          ))}
          {message.reference ? (
            <p className="mt-3 rounded-xl bg-gold/25 px-3 py-2 text-sm font-semibold text-foreground">
              Your assistance reference: {message.reference}
            </p>
          ) : null}
        </div>
        {message.programs && message.programs.length > 0 ? (
          <ul className="mt-3 grid gap-3">
            {message.programs.map((p) => (
              <li key={p.name} className="rounded-2xl border border-border bg-card p-4 shadow-sm">
                <h4 className="font-display text-lg font-bold">{p.name}</h4>
                <dl className="mt-2 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
                  {[
                    ["Sport", p.discipline],
                    ["Organization", p.organization],
                    ["Location", p.location],
                    ["Ages", p.ageRange],
                    ["Cost", p.cost],
                    ["Equipment", p.equipment],
                    ["Accessibility", p.accessibility],
                    ["Why it may be a match", p.whyMatch],
                    ["Next step", p.nextStep],
                  ].map(([label, value]) => (
                    <div key={label as string}>
                      <dt className="font-semibold text-muted-foreground">{label}</dt>
                      <dd>{value && String(value).trim() ? value : "Contact the program to confirm"}</dd>
                    </div>
                  ))}
                </dl>
              </li>
            ))}
          </ul>
        ) : null}
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              void navigator.clipboard?.writeText(message.text);
              setCopied(true);
              window.setTimeout(() => setCopied(false), 2000);
            }}
            className="inline-flex min-h-11 items-center gap-1.5 rounded-full border border-border px-3 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          >
            {copied ? <Check aria-hidden="true" className="size-4" /> : <Copy aria-hidden="true" className="size-4" />}
            {copied ? "Copied" : "Copy response"}
          </button>
          <button
            type="button"
            aria-pressed={feedback === "up"}
            onClick={() => rate("up")}
            className="inline-flex min-h-11 min-w-11 items-center justify-center gap-1.5 rounded-full border border-border px-3 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground aria-pressed:border-primary aria-pressed:text-primary"
          >
            <ThumbsUp aria-hidden="true" className="size-4" /> Helpful
          </button>
          <button
            type="button"
            aria-pressed={feedback === "down"}
            onClick={() => rate("down")}
            className="inline-flex min-h-11 min-w-11 items-center justify-center gap-1.5 rounded-full border border-border px-3 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground aria-pressed:border-primary aria-pressed:text-primary"
          >
            <ThumbsDown aria-hidden="true" className="size-4" /> Not helpful
          </button>
          {feedback ? (
            <span aria-live="polite" className="text-sm text-muted-foreground">
              Thanks for the feedback.
            </span>
          ) : null}
        </div>
        {feedback === "down" ? (
          <p className="mt-2 text-sm text-muted-foreground">
            Sorry that missed the mark.{" "}
            <button type="button" onClick={onAskPerson} className="font-medium text-primary underline underline-offset-4">
              Ask a person for help
            </button>{" "}
            or{" "}
            <a
              href="mailto:information@usafencing.org?subject=Sport%20Compass%20-%20incorrect%20answer"
              className="font-medium text-primary underline underline-offset-4"
            >
              report this answer
            </a>
            .
          </p>
        ) : null}
        {LOCATION_PROMPT.test(message.text) ? (
          <div className="mt-3">
            <button
              type="button"
              onClick={() => void shareLocation()}
              disabled={locState === "busy"}
              className="inline-flex min-h-11 items-center gap-2 rounded-full border border-primary/40 bg-primary/5 px-4 text-sm font-semibold text-primary hover:bg-primary/10 disabled:opacity-60"
            >
              <MapPin aria-hidden="true" className="size-4" />
              {locState === "busy" ? "Finding your area…" : "Share my location"}
            </button>
            <p aria-live="polite" className="mt-2 text-sm text-muted-foreground">
              {locState === "error"
                ? "We couldn’t get your location. Please type your city or ZIP code instead."
                : ""}
            </p>
          </div>
        ) : null}
        {isLatest && isYesNoQuestion(message.text) ? (
          <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label="Quick reply">
            {["Yes", "No"].map((reply) => (
              <button
                key={reply}
                type="button"
                onClick={() => onFollowUp(reply)}
                className="min-h-11 rounded-full border border-primary/40 bg-primary/5 px-6 text-sm font-semibold text-primary hover:bg-primary/10"
              >
                {reply}
              </button>
            ))}
          </div>
        ) : null}
        {message.followUps && message.followUps.length > 0 ? (

          <ul className="mt-3 flex flex-wrap gap-2">
            {message.followUps.map((q) => (
              <li key={q}>
                <button
                  type="button"
                  onClick={() => onFollowUp(q)}
                  className="min-h-11 rounded-full border border-primary/40 bg-primary/5 px-4 text-left text-sm font-medium text-primary hover:bg-primary/10"
                >
                  {q}
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </li>
  );
}

interface AssistanceForm {
  name: string;
  method: "email" | "phone";
  email: string;
  phone: string;
  reason: string;
  program: string;
  language: string;
}

const EMPTY_ASSIST: Omit<AssistanceForm, "language"> = {
  name: "",
  method: "email",
  email: "",
  phone: "",
  reason: "",
  program: "",
};

export function FencingChat() {
  const [language, setLanguage] = useState("en");
  const { messages, busy, loadingLabel, lastError, configWarning, send, retry, startNewConversation, sendFeedback } =
    useChat(language);
  const [draft, setDraft] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [assist, setAssist] = useState<AssistanceForm | null>(null);
  const [assistErrors, setAssistErrors] = useState<{ email?: string | undefined; phone?: string | undefined }>({});
  const [savePrompt, setSavePrompt] = useState(false);
  const emailRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const listEndRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const firstRenderRef = useRef(true);

  const ask = useCallback(
    (question: string, intent?: Parameters<typeof send>[1]) => {
      void send(question, intent ?? {});
    },
    [send],
  );

  useEffect(() => {
    function onAsk(event: Event) {
      const detail = (event as CustomEvent<{ question?: string; intent?: string; focus?: boolean }>).detail ?? {};
      document.getElementById("chat")?.scrollIntoView({ block: "start" });
      window.setTimeout(() => inputRef.current?.focus(), 350);
      if (detail.question) {
        const intent = parseTool(detail.intent);
        ask(detail.question, intent ? { intent } : undefined);
      }
    }
    window.addEventListener("s4a:ask", onAsk as EventListener);
    return () => window.removeEventListener("s4a:ask", onAsk as EventListener);
  }, [ask]);

  useEffect(() => {
    if (firstRenderRef.current) {
      firstRenderRef.current = false;
      return;
    }
    const list = listRef.current;
    if (list) list.scrollTop = list.scrollHeight;
  }, [messages, busy]);

  useEffect(() => {
    if (!expanded) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setExpanded(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [expanded]);

  function submit() {
    const text = draft.trim();
    if (!text || busy) return;
    setDraft("");
    ask(text);
  }

  const started = messages.length > 0;

  return (
    <div
      id="chat"
      className={
        expanded
          ? "fixed inset-0 z-50 flex flex-col bg-background pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]"
          : "mx-auto flex w-full max-w-4xl scroll-mt-24 flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-xl shadow-navy/10"
      }
      role={expanded ? "dialog" : undefined}
      aria-modal={expanded ? true : undefined}
      aria-label={expanded ? "Sport Compass, full screen" : undefined}
    >
      {/* Header */}
      <div className="flex flex-wrap items-start gap-3 border-b border-border bg-navy px-4 py-4 text-navy-foreground sm:px-6">
        <AgentAvatar />
        <div className="min-w-0 flex-1">
          <h2 className="text-xl font-bold text-navy-foreground">Sport Compass</h2>
          <p className="mt-1 text-sm text-navy-foreground/80">
            Ask about adaptive fencing, equipment, fencing disciplines, getting started, programs, accommodations, or
            competition pathways.
          </p>
          <p className="mt-2 flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-wide text-gold">
            <ShieldCheck aria-hidden="true" className="size-4" /> Powered by Salesforce Agentforce + Data Cloud
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <p className="inline-flex min-h-11 w-[8.5rem] shrink-0 items-center justify-center gap-2 rounded-full bg-white/10 px-3 text-sm">
            {busy ? <Loader2 aria-hidden="true" className="size-4 animate-spin" /> : <Check aria-hidden="true" className="size-4" />}
            <span aria-hidden="true">{busy ? "Working…" : "Ready"}</span>
            <span className="sr-only">{busy ? "Working on your answer" : "Ready"}</span>
          </p>
          <label className="sr-only" htmlFor="chat-language">
            Answer language
          </label>
          <select
            id="chat-language"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="min-h-11 rounded-full bg-white/10 px-3 text-sm text-navy-foreground"
          >
            {LANGUAGES.map((l) => (
              <option key={l.code} value={l.code} className="text-foreground">
                {l.label}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => void startNewConversation()}
            className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white/10 px-3 text-sm font-medium hover:bg-white/20"
          >
            <RefreshCw aria-hidden="true" className="size-4" /> New conversation
          </button>
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="inline-flex min-h-11 min-w-11 items-center justify-center gap-2 rounded-full bg-white/10 px-3 text-sm font-medium hover:bg-white/20"
          >
            {expanded ? <X aria-hidden="true" className="size-4" /> : <Maximize2 aria-hidden="true" className="size-4" />}
            <span>{expanded ? "Close full screen" : "Full screen"}</span>
          </button>
        </div>
      </div>

      {/* Conversation */}
      <div ref={listRef} className={expanded ? "flex-1 overflow-y-auto px-4 py-5 sm:px-6" : "max-h-[32rem] min-h-[22rem] overflow-y-auto px-4 py-5 sm:px-6"}>
        <div className="mx-auto max-w-2xl">
          <div className="flex gap-3">
            <AgentAvatar size={36} />
            <p className="rounded-2xl rounded-bl-md border border-border bg-piste px-4 py-3">{WELCOME}</p>
          </div>

          {!started ? (
            <div className="mt-5">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                Try one of these questions
              </h3>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {EXAMPLES.map((q) => (
                  <li key={q}>
                    <button
                      type="button"
                      onClick={() => ask(q)}
                      className="min-h-11 w-full rounded-2xl border border-border bg-card px-4 py-3 text-left font-medium shadow-sm transition-colors hover:border-primary hover:bg-primary/5"
                    >
                      {q}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <ul className="mt-5 space-y-5">
            {messages.map((m, i) => (
              <MessageBubble
                key={m.id}
                message={m}
                isLatest={i === messages.length - 1 && !busy}
                onFollowUp={(q) => ask(q)}
                onFeedback={sendFeedback}
                onAskPerson={() => ask("I'd like someone to help us get started.", { intent: "request_human_assistance" })}
                onShareLocation={(place) => ask(`I'm in ${place}.`, { intent: "find_sports_programs" })}

              />
            ))}
          </ul>

          <div aria-live="polite" aria-atomic="false" className="mt-4">
            {busy ? (
              <p className="flex items-center gap-2 text-muted-foreground">
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                {loadingLabel}
              </p>
            ) : null}
            {!busy && lastError === "timeout" ? (
              <button
                type="button"
                onClick={retry}
                className="min-h-11 rounded-full bg-primary px-5 font-semibold text-primary-foreground"
              >
                Try again
              </button>
            ) : null}
          </div>

          {configWarning ? (
            <p className="mt-3 rounded-xl border border-destructive bg-destructive/10 px-3 py-2 text-sm">
              {configWarning}
            </p>
          ) : null}

          {/* Consent-gated actions */}
          <div className="mt-6 flex flex-wrap gap-2 border-t border-border pt-4">
            <button
              type="button"
              onClick={() => setSavePrompt(true)}
              className="min-h-11 rounded-full border border-border px-4 text-sm font-medium hover:bg-accent"
            >
              Save my preferences
            </button>
            <button
              type="button"
              onClick={() => {
                setAssistErrors({});
                setAssist({ ...EMPTY_ASSIST, language });
              }}
              className="min-h-11 rounded-full border border-border px-4 text-sm font-medium hover:bg-accent"
            >
              Ask a program specialist to follow up
            </button>
          </div>

          {savePrompt ? (
            <div className="mt-4 rounded-2xl border border-border bg-piste p-4">
              <p className="font-medium">
                Would you like me to save these preferences so the organization can help you find an appropriate
                program?
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSavePrompt(false);
                    ask("Please save my preferences from this conversation.", {
                      intent: "save_participant_preferences",
                      details: { location: "", notes: "Preferences shared in this conversation." },
                    });
                  }}
                  className="min-h-11 rounded-full bg-primary px-5 font-semibold text-primary-foreground"
                >
                  Yes, save my preferences
                </button>
                <button
                  type="button"
                  onClick={() => setSavePrompt(false)}
                  className="min-h-11 rounded-full border border-border px-5 font-medium"
                >
                  Not now
                </button>
              </div>
            </div>
          ) : null}

          {assist ? (
            <form
              className="mt-4 space-y-3 rounded-2xl border border-border bg-piste p-4"
              noValidate
              onSubmit={(e) => {
                e.preventDefault();
                const payload = assist;
                const errors: { email?: string | undefined; phone?: string | undefined } = {};
                const mailError = emailError(payload.email);
                if (mailError) errors.email = mailError;
                if (payload.method === "phone") {
                  const telError = phoneError(payload.phone);
                  if (telError) errors.phone = telError;
                }
                setAssistErrors(errors);
                if (errors.email || errors.phone) {
                  window.setTimeout(() => {
                    if (errors.email) emailRef.current?.focus();
                    else phoneRef.current?.focus();
                  }, 0);
                  return;
                }
                setAssist(null);
                setAssistErrors({});
                ask(payload.reason || "A visitor would like help from a program specialist.", {
                  intent: "request_human_assistance",
                  details: {
                    participant_name: payload.name,
                    preferred_contact_method: payload.method,
                    contact_email: payload.email.trim(),
                    ...(payload.method === "phone" ? { contact_phone: payload.phone.trim() } : {}),
                    urgency: "normal",
                  },
                });
              }}
            >
              <p>
                I can ask a program specialist to follow up. Only the information you choose to provide will be sent to
                the organization.
              </p>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="assist-name" className="text-sm font-medium">
                    First name or preferred name
                  </label>
                  <input
                    id="assist-name"
                    value={assist.name}
                    onChange={(e) => setAssist({ ...assist, name: e.target.value })}
                    className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3"
                  />
                </div>
                <div>
                  <label htmlFor="assist-method" className="text-sm font-medium">
                    Preferred contact method
                  </label>
                  <select
                    id="assist-method"
                    value={assist.method}
                    onChange={(e) => setAssist({ ...assist, method: e.target.value as "email" | "phone" })}
                    className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3"
                  >
                    <option value="email">Email</option>
                    <option value="phone">Phone</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="assist-email" className="text-sm font-medium">
                    Email address <span className="text-muted-foreground">(required)</span>
                  </label>
                  <input
                    id="assist-email"
                    ref={emailRef}
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    required
                    aria-required="true"
                    aria-invalid={assistErrors.email ? true : undefined}
                    aria-describedby={assistErrors.email ? "assist-email-error" : undefined}
                    value={assist.email}
                    onChange={(e) => {
                      setAssist({ ...assist, email: e.target.value });
                      if (assistErrors.email) setAssistErrors({ ...assistErrors, email: undefined });
                    }}
                    onBlur={(e) => setAssistErrors({ ...assistErrors, email: emailError(e.target.value) })}
                    className={`mt-1 min-h-11 w-full rounded-xl border bg-background px-3 ${
                      assistErrors.email ? "border-destructive" : "border-input"
                    }`}
                  />
                  {assistErrors.email ? (
                    <p id="assist-email-error" className="mt-1 text-sm font-medium text-destructive">
                      {assistErrors.email}
                    </p>
                  ) : null}
                </div>
                {assist.method === "phone" ? (
                  <div>
                    <label htmlFor="assist-phone" className="text-sm font-medium">
                      Phone number <span className="text-muted-foreground">(required)</span>
                    </label>
                    <input
                      id="assist-phone"
                      ref={phoneRef}
                      type="tel"
                      autoComplete="tel"
                      required
                      aria-required="true"
                      aria-invalid={assistErrors.phone ? true : undefined}
                      aria-describedby={assistErrors.phone ? "assist-phone-error" : undefined}
                      value={assist.phone}
                      onChange={(e) => {
                        setAssist({ ...assist, phone: e.target.value });
                        if (assistErrors.phone) setAssistErrors({ ...assistErrors, phone: undefined });
                      }}
                      onBlur={(e) => setAssistErrors({ ...assistErrors, phone: phoneError(e.target.value) })}
                      className={`mt-1 min-h-11 w-full rounded-xl border bg-background px-3 ${
                        assistErrors.phone ? "border-destructive" : "border-input"
                      }`}
                    />
                    {assistErrors.phone ? (
                      <p id="assist-phone-error" className="mt-1 text-sm font-medium text-destructive">
                        {assistErrors.phone}
                      </p>
                    ) : null}
                  </div>
                ) : null}
                <div>
                  <label htmlFor="assist-program" className="text-sm font-medium">
                    Program of interest (optional)
                  </label>
                  <input
                    id="assist-program"
                    value={assist.program}
                    onChange={(e) => setAssist({ ...assist, program: e.target.value })}
                    className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="assist-reason" className="text-sm font-medium">
                  General reason for assistance
                </label>
                <textarea
                  id="assist-reason"
                  required
                  rows={3}
                  value={assist.reason}
                  onChange={(e) => setAssist({ ...assist, reason: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="submit" className="min-h-11 rounded-full bg-primary px-5 font-semibold text-primary-foreground">
                  Yes, send this request
                </button>
                <button
                  type="button"
                  onClick={() => setAssist(null)}
                  className="min-h-11 rounded-full border border-border px-5 font-medium"
                >
                  Not now
                </button>
              </div>
            </form>
          ) : null}

          <div ref={listEndRef} />
        </div>
      </div>

      {/* Composer */}
      <div className="sticky bottom-0 border-t border-border bg-card px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-6">
        <div className="mx-auto flex max-w-2xl items-end gap-2">
          <div className="flex-1">
            <label htmlFor="chat-input" className="sr-only">
              Ask Sport Compass a question
            </label>
            <textarea
              id="chat-input"
              ref={inputRef}
              rows={2}
              value={draft}
              maxLength={MAX_CHARS}
              placeholder={"Ask anything about fencing…"}
              aria-describedby="chat-input-help"
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  submit();
                }
              }}
              className="w-full resize-none rounded-2xl border border-input bg-background px-4 py-3 text-base"
            />
            <p id="chat-input-help" className="mt-1 text-xs text-muted-foreground">
              Press Enter to send, Shift + Enter for a new line. {draft.length}/{MAX_CHARS} characters.
            </p>
          </div>
          <button
            type="button"
            onClick={submit}
            disabled={busy || draft.trim().length === 0}
            className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Send aria-hidden="true" className="size-4" /> Send
          </button>
        </div>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import type { ChatResponseBody, ChatTool, ProgramCard } from "@/lib/chat/routing";

export interface ChatMessage {
  id: string;
  role: "user" | "agent";
  text: string;
  state?: "sending" | "sent" | "error" | undefined;
  followUps?: string[] | undefined;
  reference?: string | null | undefined;
  programs?: ProgramCard[] | undefined;
}

const STORAGE_KEY = "s4a_chat_messages";
const TOKEN_KEY = "s4a_chat_token";

function readToken(): string | null {
  try {
    return window.localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

function writeToken(token: string | undefined) {
  if (!token) return;
  try {
    window.localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* storage may be unavailable */
  }
}
const LOADING_LABELS = [
  "Connecting to Sport Compass…",
  "Reviewing trusted program information…",
  "Preparing your answer…",
];

function uid(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export interface SendOptions {
  intent?: ChatTool;
  details?: Record<string, unknown>;
}

export function useChat(language: string) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [loadingLabel, setLoadingLabel] = useState(LOADING_LABELS[0]!);
  const [lastError, setLastError] = useState<ChatResponseBody["error"]>(null);
  const [configWarning, setConfigWarning] = useState<string | null>(null);
  const lastQuestion = useRef<{ text: string; options: SendOptions } | null>(null);
  const busyRef = useRef(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const stored = JSON.parse(raw) as ChatMessage[];
      // Never clobber a question that was already submitted while mounting
      // (for example a scenario link that lands on /ask and sends at once).
      setMessages((prev) => (prev.length ? prev : stored));
    } catch {
      /* ignore unreadable history */
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(-40)));
    } catch {
      /* storage may be unavailable */
    }
  }, [messages]);

  useEffect(() => {
    if (!busy) return;
    let index = 0;
    const timer = window.setInterval(() => {
      index = (index + 1) % LOADING_LABELS.length;
      setLoadingLabel(LOADING_LABELS[index]!);
    }, 2600);
    return () => window.clearInterval(timer);
  }, [busy]);

  const send = useCallback(
    async (text: string, options: SendOptions = {}) => {
      const question = text.trim();
      if (!question || busyRef.current) return;
      busyRef.current = true;
      setBusy(true);
      setLastError(null);
      setLoadingLabel(LOADING_LABELS[0]!);
      lastQuestion.current = { text: question, options };

      const userId = uid();
      setMessages((prev) => [
        ...prev,
        { id: userId, role: "user", text: question, state: "sending" },
      ]);

      // A short, privacy-conscious summary of recent turns so that brief
      // replies such as "yes" still make sense to the agent.
      const context = messages
        .slice(-6)
        .map((m) => `${m.role === "user" ? "Visitor asked" : "Assistant answered"}: ${m.text.slice(0, 400)}`)
        .join("\n")
        .slice(0, 1900);

      try {
        const response = await fetch("/api/sports-for-all-chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({
            message: question,
            language,
            conversationContext: context,
            action: "message",
            ...(readToken() ? { sessionToken: readToken() } : {}),
            ...(options.intent ? { intent: options.intent } : {}),
            ...(options.details ? { details: options.details } : {}),
          }),
        });
        const data = (await response.json()) as ChatResponseBody;
        writeToken(data.sessionToken);
        setMessages((prev) =>
          prev
            .map((m) =>
              m.id === userId ? { ...m, state: (data.error ? "error" : "sent") as ChatMessage["state"] } : m,
            )
            .concat({
              id: uid(),
              role: "agent",
              text: data.reply,
              followUps: data.followUps ?? [],
              reference: data.reference ?? null,
              programs: data.programs ?? [],
            } as ChatMessage),
        );
        setLastError(data.error ?? null);
        setConfigWarning(data.configWarning ?? null);
      } catch {
        setMessages((prev) =>
          prev
            .map((m) => (m.id === userId ? { ...m, state: "error" as const } : m))
            .concat({
              id: uid(),
              role: "agent",
              text: "The assistant is temporarily unavailable. Please try again shortly.",
            }),
        );
        setLastError("unavailable");
      } finally {
        busyRef.current = false;
        setBusy(false);
      }
    },
    [language, messages],
  );

  const retry = useCallback(() => {
    const last = lastQuestion.current;
    if (last) void send(last.text, last.options);
  }, [send]);

  const startNewConversation = useCallback(async () => {
    setMessages([]);
    setLastError(null);
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    const token = readToken();
    try {
      window.localStorage.removeItem(TOKEN_KEY);
    } catch {
      /* ignore */
    }
    await fetch("/api/sports-for-all-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ action: "reset", language, ...(token ? { sessionToken: token } : {}) }),
    })
      .then((r) => r.json())
      .then((d: ChatResponseBody) => writeToken(d.sessionToken))
      .catch(() => undefined);
  }, [language]);

  /** Records an anonymous thumbs up/down. Never sends question or answer text. */
  const sendFeedback = useCallback(
    (value: "up" | "down") => {
      const token = readToken();
      void fetch("/api/sports-for-all-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ action: "feedback", feedback: value, language, ...(token ? { sessionToken: token } : {}) }),
      })
        .then((r) => r.json())
        .then((d: ChatResponseBody) => writeToken(d.sessionToken))
        .catch(() => undefined);
    },
    [language],
  );

  return { messages, busy, loadingLabel, lastError, configWarning, send, retry, startNewConversation, sendFeedback };
}

import { createFileRoute } from "@tanstack/react-router";
import { useAsk } from "@/components/site/ask";
import { WeaponsSection } from "@/components/site/WeaponsSection";
import { PathwaySection } from "@/components/site/PathwaySection";

export const Route = createFileRoute("/fencing-for-all")({
  head: () => ({
    meta: [
      { title: "Fencing Is for Everyone | Sports 4 All" },
      {
        name: "description",
        content:
          "Start at any age, adapt the sport to your body, compare foil, épée and sabre, and follow the pathway from a first lesson to the Paralympics.",
      },
      { property: "og:title", content: "Fencing Is for Everyone | Sports 4 All" },
      {
        property: "og:description",
        content: "Adaptive and standing fencing: where to start, which weapon fits you and how the pathway works.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://sports-4-all.org/fencing-for-all" },
    ],
    links: [{ rel: "canonical", href: "https://sports-4-all.org/fencing-for-all" }],
  }),
  component: Page,
});

const CARDS = [
  {
    title: "Start at Any Age",
    body: "Fencers begin at eight and at eighty. Clubs run beginner courses year-round, and progress is measured against yourself first.",
  },
  {
    title: "Adapt the Sport",
    body: "Wheelchair fencing frames, seated bouts, grip adaptations and coaching adjustments keep the sport fast, fair and demanding.",
  },
  {
    title: "Choose Your Weapon",
    body: "Épée, foil and sabre reward different instincts. Most beginners try more than one before choosing.",
  },
];

const JUMP_LINKS = [
  { hash: "weapons", label: "Foil, épée and sabre" },
  { hash: "pathway", label: "From first lesson to the Paralympics" },
];

function Page() {
  const ask = useAsk();
  return (
    <>
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <h1 className="font-display text-3xl font-extrabold sm:text-4xl">Fencing Is for Everyone</h1>
        <ul className="mt-6 flex flex-wrap gap-2">
          {JUMP_LINKS.map((l) => (
            <li key={l.hash}>
              <a
                href={`#${l.hash}`}
                className="inline-flex min-h-11 items-center rounded-full border border-border px-4 font-medium hover:bg-accent hover:text-accent-foreground"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <ul className="mt-8 grid gap-5 md:grid-cols-3">
          {CARDS.map((c) => (
            <li key={c.title} className="rounded-3xl border border-border bg-card p-6 shadow-sm">
              <h2 className="font-display text-xl font-bold">{c.title}</h2>
              <p className="mt-3 text-muted-foreground">{c.body}</p>
            </li>
          ))}
        </ul>
        <button
          type="button"
          onClick={() => ask("I'm not sure where to begin with fencing. Where should I start?")}
          className="mt-8 min-h-11 rounded-full bg-primary px-6 font-semibold text-primary-foreground"
        >
          Not sure where to begin? Ask Sport Compass
        </button>
      </section>
      <WeaponsSection />
      <PathwaySection />
    </>
  );
}

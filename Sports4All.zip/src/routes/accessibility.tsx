import { createFileRoute } from "@tanstack/react-router";
import { useAsk } from "@/components/site/ask";
import { AccessibilitySection } from "@/components/site/ImpactSections";
import community from "@/assets/community-fencers.jpg";

export const Route = createFileRoute("/accessibility")({
  head: () => ({
    meta: [
      { title: "Fencing From a Wheelchair | Sports 4 All" },
      {
        name: "description",
        content:
          "How wheelchair fencing works, what clubs provide and how to find a program that welcomes seated and standing athletes together.",
      },
      { property: "og:title", content: "Fencing From a Wheelchair | Sports 4 All" },
      {
        property: "og:description",
        content: "Close, quick, explosive bouts — how wheelchair fencing works and how to get started.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://sports-4-all.org/accessibility" },
    ],
    links: [{ rel: "canonical", href: "https://sports-4-all.org/accessibility" }],
  }),
  component: Page,
});

function Page() {
  const ask = useAsk();
  return (
    <>
    <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2">
      <img
        src={community}
        alt="Wheelchair and standing fencers training together in a bright club hall"
        width={1200}
        height={800}
        className="w-full rounded-3xl object-cover shadow-lg"
      />
      <div>
        <h1 className="font-display text-3xl font-extrabold sm:text-4xl">Fencing From a Wheelchair</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Wheelchair fencing anchors both athletes to frames set at fixed distance. Bouts are close, quick and
          explosive, testing blade work, timing and reading your opponent. Many clubs welcome both seated and standing
          fencers in the same session.
        </p>
        <div className="mt-7 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => ask("Can my daughter fence from a wheelchair?")}
            className="min-h-11 rounded-full bg-primary px-6 font-semibold text-primary-foreground"
          >
            Can my daughter fence from a wheelchair?
          </button>
          <button
            type="button"
            onClick={() => ask("Can you help me find an accessible fencing program near me?", "find_sports_programs")}
            className="min-h-11 rounded-full border border-border px-6 font-semibold"
          >
            Find an Accessible Program
          </button>
        </div>
      </div>
    </section>
    <AccessibilitySection />
    </>
  );
}

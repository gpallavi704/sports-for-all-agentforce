/**
 * Server-side chat endpoint ("sports-for-all-chat").
 *
 * This is the only component that speaks MCP. The browser posts a plain
 * message here and receives consumer-safe text. No Salesforce credentials,
 * MCP payloads, Agentforce session ids, or sequence numbers cross this line.
 */
import { createFileRoute } from "@tanstack/react-router";
import { callTool, listTools, probeEndpoint } from "@/lib/chat/mcp-client.server";
import {
  categorizeQuestion,
  routeTool,
  type ChatRequestBody,
  type ChatResponseBody,
  type ChatTool,
} from "@/lib/chat/routing";
import {
  claimSession,
  cookieHeader,
  createSession,
  hashToken,
  loadSession,
  newToken,
  readCookieToken,
  releaseSession,
  resetSession,
  trackEvent,
} from "@/lib/chat/session.server";

const MAX_MESSAGE = 1500;
const MAX_CONTEXT = 2000;

function json(body: ChatResponseBody, extraHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status: 200,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...extraHeaders },
  });
}

function empty(): ChatResponseBody {
  return { reply: "", followUps: [], tool: null, programs: [], error: null };
}

/** True when the failure means the Agentforce conversation itself is gone. */
function isExpiredSession(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error ?? "");
  return /session (not found|expired|invalid)|invalid session|404/i.test(message);
}

function isDev(): boolean {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  return (env?.["NODE_ENV"] ?? "development") !== "production";
}

function followUpsFrom(structured: Record<string, unknown>): string[] {
  const raw = structured["suggested_follow_up_questions"];
  if (!Array.isArray(raw)) return [];
  return raw.filter((v): v is string => typeof v === "string" && v.trim().length > 0).slice(0, 3);
}

function referenceFrom(text: string): string | null {
  const match = text.match(/\b(?:case|reference|ticket)\s*(?:number|id|#)?\s*[:#]?\s*([A-Za-z0-9-]{4,20})\b/i);
  return match?.[1] ?? null;
}

function buildArgs(
  tool: ChatTool,
  body: ChatRequestBody,
  message: string,
  language: string,
  agentSessionId: string | null,
  sequenceId: number,
): Record<string, unknown> {
  const context = (body.conversationContext ?? "").slice(0, MAX_CONTEXT).trim();
  switch (tool) {
    case "ask_fencing_question":
      return {
        question: message,
        language,
        ...(context ? { conversation_context: context } : {}),
        ...(agentSessionId ? { agentforce_session_id: agentSessionId, sequence_id: sequenceId } : {}),
      };
    case "find_sports_programs":
      return {
        location: (body.details?.["location"] as string) || message,
        sport: "fencing",
        ...(body.details?.["participant_age"] ? { participant_age: body.details["participant_age"] } : {}),
        ...(body.details?.["accessibility_needs"]
          ? { accessibility_needs: body.details["accessibility_needs"] }
          : {}),
        ...(agentSessionId ? { session_id: agentSessionId, sequence_id: sequenceId - 1 } : {}),
      };
    case "get_program_details":
      return {
        ...(body.details?.["program_name"] ? { program_name: body.details["program_name"] } : {}),
        question: message,
        ...(agentSessionId ? { session_id: agentSessionId, sequence_id: sequenceId - 1 } : {}),
      };
    default:
      return {
        ...(body.details ?? {}),
        ...(tool === "request_human_assistance" ? { reason: message } : {}),
        ...(agentSessionId ? { session_id: agentSessionId, sequence_id: sequenceId - 1 } : {}),
      };
  }
}

export const Route = createFileRoute("/api/sports-for-all-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const started = Date.now();
        const secure = new URL(request.url).protocol === "https:";

        let body: ChatRequestBody;
        try {
          body = (await request.json()) as ChatRequestBody;
        } catch {
          return json({ ...empty(), reply: "That request could not be read.", error: "invalid" });
        }

        // --- resolve the opaque browser token -> server-side session row ----
        // Cookie first; fall back to the opaque token the browser echoes back
        // (browsers block the cookie inside cross-site preview frames).
        let token = readCookieToken(request) ?? (typeof body.sessionToken === "string" && /^[a-f0-9]{64}$/.test(body.sessionToken) ? body.sessionToken : null);
        let setCookie: string | null = null;
        const language = (body.language ?? "en").slice(0, 20) || "en";

        let tokenHash = token ? await hashToken(token) : null;
        let session = tokenHash ? await loadSession(tokenHash) : null;
        if (!session) {
          token = newToken();
          tokenHash = await hashToken(token);
          setCookie = cookieHeader(token, secure);
          session = await createSession(tokenHash, language);
        }
        const headers = setCookie ? { "Set-Cookie": setCookie } : {};
        const visitorToken = token!;

        if (body.action === "reset") {
          await resetSession(tokenHash!);
          await trackEvent({
            session_id: session.id,
            event_type: "new_conversation_started",
            language,
          });
          return json({ ...empty(), reply: "", sessionToken: visitorToken }, headers);
        }

        if (body.action === "feedback") {
          const value = body.feedback === "up" ? true : body.feedback === "down" ? false : null;
          if (value === null) {
            return json({ ...empty(), reply: "", error: "invalid", sessionToken: visitorToken }, headers);
          }
          await trackEvent({
            session_id: session.id,
            event_type: "answer_feedback",
            language,
            success: value,
          });
          return json({ ...empty(), reply: "", sessionToken: visitorToken }, headers);
        }

        if (body.action === "diagnostics") {
          if (!isDev()) return new Response("Not found", { status: 404 });
          const probe = await probeEndpoint(request.url);
          return new Response(
            JSON.stringify({
              ...probe,
              publicSessionActive: true,
              agentforceSessionExists: Boolean(session.agentforce_session_id),
              nextSequenceId: session.next_sequence_id,
              sessionToken: visitorToken,
            }),
            { status: 200, headers: { "Content-Type": "application/json", ...headers } },
          );
        }

        const message = (body.message ?? "").trim();
        if (!message) {
          return json({ ...empty(), reply: "Please enter a fencing question.", error: "invalid", sessionToken: visitorToken }, headers);
        }
        if (message.length > MAX_MESSAGE) {
          return json(
            {
              ...empty(),
              reply: `Please shorten your question to ${MAX_MESSAGE} characters or fewer.`,
              error: "invalid",
              sessionToken: visitorToken,
            },
            headers,
          );
        }

        // --- tool discovery ------------------------------------------------
        let tools;
        try {
          tools = await listTools(request.url);
        } catch {
          await trackEvent({
            session_id: session.id,
            event_type: "error",
            error_category: "tool_discovery",
            language,
            success: false,
          });
          return json(
            {
              ...empty(),
              reply: "The assistant is temporarily unavailable. Please try again shortly.",
              error: "unavailable",
              sessionToken: visitorToken,
            },
            headers,
          );
        }

        const tool = routeTool(message, body.intent);
        const available = tools.some((t) => t.name === tool);
        if (!available) {
          return json(
            {
              ...empty(),
              reply: "The assistant is temporarily unavailable. Please try again shortly.",
              error: "config",
              sessionToken: visitorToken,
              configWarning: isDev()
                ? `Configuration warning: the tool "${tool}" was not returned by tools/list.`
                : null,
            },
            headers,
          );
        }

        // --- atomically claim the session ----------------------------------
        const claimed = await claimSession(session.id);
        if (!claimed) {
          return json(
            {
              ...empty(),
              reply: "Please wait for the current response before sending another message.",
              error: "busy",
              sessionToken: visitorToken,
            },
            headers,
          );
        }

        const category = categorizeQuestion(message);
        await trackEvent({
          session_id: session.id,
          event_type: "question_submitted",
          question_category: category,
          tool_name: tool,
          language,
        });

        try {
          const result = await callTool(
            request.url,
            tool,
            buildArgs(tool, body, message, language, claimed.agentforce_session_id, claimed.next_sequence_id),
          );

          const structured = result.structured;
          const agentSessionId =
            (structured["agentforce_session_id"] as string | undefined) ??
            (structured["session_id"] as string | undefined) ??
            claimed.agentforce_session_id;
          const nextSequence =
            (structured["next_sequence_id"] as number | undefined) ??
            ((structured["sequence_id"] as number | undefined) ?? claimed.next_sequence_id) + 1;

          const reply =
            (structured["answer"] as string | undefined) ||
            result.text ||
            "The assistant is temporarily unavailable. Please try again shortly.";

          await releaseSession(session.id, {
            agentforce_session_id: agentSessionId ?? null,
            next_sequence_id: nextSequence,
            language,
            last_tool_name: tool,
            last_question_category: category,
            message_count: claimed.message_count + 1,
          });

          await trackEvent({
            session_id: session.id,
            event_type: "agentforce_response_received",
            question_category: category,
            tool_name: tool,
            language,
            success: !result.isError,
            response_time_ms: Date.now() - started,
            human_escalation: tool === "request_human_assistance",
            program_result_count: Array.isArray(structured["programs"])
              ? (structured["programs"] as unknown[]).length
              : 0,
          });

          return json(
            {
              reply,
              followUps: followUpsFrom(structured),
              tool,
              programs: [],
              reference: tool === "request_human_assistance" ? referenceFrom(reply) : null,
              error: null,
              sessionToken: visitorToken,
            },
            headers,
          );
        } catch (error) {
          const kind =
            error instanceof Error && /abort|timeout/i.test(error.message) ? "timeout" : "unavailable";
          const expiredSession = isExpiredSession(error);
          await releaseSession(session.id, {
            // Only drop the Agentforce conversation when it is genuinely gone;
            // a transient failure must not silently restart the conversation.
            ...(expiredSession ? { agentforce_session_id: null, next_sequence_id: 1 } : {}),
          });
          await trackEvent({
            session_id: session.id,
            event_type: kind,
            question_category: category,
            tool_name: tool,
            language,
            success: false,
            error_category: kind,
            response_time_ms: Date.now() - started,
          });
          return json(
            {
              ...empty(),
              reply:
                kind === "timeout"
                  ? "Sport Compass is taking longer than expected. Would you like to try again?"
                  : expiredSession
                    ? "Let\u2019s start a fresh conversation so I can continue helping you."
                    : "The assistant is temporarily unavailable. Please try again shortly.",
              error: expiredSession ? "expired" : kind,
              sessionToken: visitorToken,
            },
            headers,
          );
        }
      },
    },
  },
});

import { createFileRoute } from "@tanstack/react-router";
import { probeEndpoint } from "@/lib/chat/mcp-client.server";

/**
 * Sanitized, aggregate-only observability feed for the /impact judge dashboard.
 * No question text, no answers, no contact details, no credentials — only counts
 * derived server-side from the privacy-conscious event log.
 */

export interface ImpactStatus {
  web: "ready" | "unavailable";
  mcp: "connected" | "unavailable";
  agentforce: "available" | "mock" | "unavailable";
  chatgptPlugin: "available" | "coming_online";
  humanEscalation: "available" | "unavailable";
  toolNames: string[];
}

export interface ImpactMetrics {
  conversations: number;
  toolCalls: number;
  questionsAnswered: number;
  programsSurfaced: number;
  humanHandoffs: number;
  languages: number;
  medianResponseMs: number | null;
  toolSuccessRate: number | null;
  helpfulRate: number | null;
  answersRated: number;
  hasData: boolean;
}

function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? Math.round(((sorted[mid - 1] ?? 0) + (sorted[mid] ?? 0)) / 2) : (sorted[mid] ?? 0);
}

async function readMetrics(): Promise<ImpactMetrics> {
  const empty: ImpactMetrics = {
    conversations: 0,
    toolCalls: 0,
    questionsAnswered: 0,
    programsSurfaced: 0,
    humanHandoffs: 0,
    languages: 0,
    medianResponseMs: null,
    toolSuccessRate: null,
    helpfulRate: null,
    answersRated: 0,
    hasData: false,
  };
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [{ count: sessionCount }, { data: events }] = await Promise.all([
      supabaseAdmin.from("agentforce_sessions").select("id", { count: "exact", head: true }),
      supabaseAdmin
        .from("chat_events")
        .select("event_type, tool_name, language, success, response_time_ms, program_result_count, human_escalation")
        .order("created_at", { ascending: false })
        .limit(5000),
    ]);

    const rows = (events ?? []) as Array<{
      event_type: string;
      tool_name: string | null;
      language: string | null;
      success: boolean | null;
      response_time_ms: number | null;
      program_result_count: number | null;
      human_escalation: boolean | null;
    }>;

    const completed = rows.filter((r) => r.event_type === "agentforce_response_received");
    const ratings = rows.filter((r) => r.event_type === "answer_feedback" && r.success !== null);
    const attempts = rows.filter((r) => r.event_type !== "answer_feedback" && r.success !== null);
    const succeeded = attempts.filter((r) => r.success === true);
    const latencies = completed
      .map((r) => r.response_time_ms)
      .filter((n): n is number => typeof n === "number" && n > 0);

    return {
      conversations: sessionCount ?? 0,
      toolCalls: succeeded.length,
      questionsAnswered: completed.filter((r) => r.success === true).length,
      programsSurfaced: rows.reduce((sum, r) => sum + (r.program_result_count ?? 0), 0),
      humanHandoffs: rows.filter(
        (r) => r.human_escalation === true || r.tool_name === "request_human_assistance",
      ).length,
      languages: new Set(rows.map((r) => r.language).filter(Boolean)).size,
      medianResponseMs: median(latencies),
      toolSuccessRate: attempts.length ? Math.round((succeeded.length / attempts.length) * 100) : null,
      helpfulRate: ratings.length
        ? Math.round((ratings.filter((r) => r.success === true).length / ratings.length) * 100)
        : null,
      answersRated: ratings.length,
      hasData: (sessionCount ?? 0) > 0 || rows.length > 0,
    };
  } catch {
    return empty;
  }
}

export const Route = createFileRoute("/api/impact-metrics")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const probe = await probeEndpoint(request.url);
        const mockMode = String(process.env["MOCK_AGENTFORCE"] ?? "").toLowerCase() === "true";
        const agentforceConfigured = Boolean(
          process.env["SALESFORCE_MY_DOMAIN_URL"] &&
            process.env["SALESFORCE_CLIENT_ID"] &&
            process.env["SALESFORCE_CLIENT_SECRET"] &&
            process.env["SALESFORCE_AGENT_ID"],
        );
        const pluginUrl = (process.env["VITE_CHATGPT_PLUGIN_URL"] ?? "").trim();

        const status: ImpactStatus = {
          web: "ready",
          mcp: probe.endpointReachable ? "connected" : "unavailable",
          agentforce: mockMode ? "mock" : agentforceConfigured && probe.endpointReachable ? "available" : "unavailable",
          chatgptPlugin: pluginUrl ? "available" : "coming_online",
          humanEscalation: probe.endpointReachable ? "available" : "unavailable",
          toolNames: [],
        };

        const metrics = await readMetrics();

        return new Response(JSON.stringify({ status, metrics, toolCount: probe.toolCount }), {
          status: 200,
          headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
        });
      },
    },
  },
});

import { createFileRoute } from "@tanstack/react-router";

/**
 * Turns coarse browser coordinates into a human place name (city, region,
 * country). Coordinates are rounded before they leave the browser and are
 * never stored — only the resulting place name is passed on to the agent.
 */
export const Route = createFileRoute("/api/reverse-geocode")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let lat: number;
        let lng: number;
        try {
          const body = (await request.json()) as { lat?: unknown; lng?: unknown };
          lat = Number(body.lat);
          lng = Number(body.lng);
        } catch {
          return Response.json({ place: null }, { status: 400 });
        }
        if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
          return Response.json({ place: null }, { status: 400 });
        }

        const url = new URL("https://api.bigdatacloud.net/data/reverse-geocode-client");
        url.searchParams.set("latitude", lat.toFixed(2));
        url.searchParams.set("longitude", lng.toFixed(2));
        url.searchParams.set("localityLanguage", "en");

        try {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 8000);
          const res = await fetch(url, { signal: controller.signal });
          clearTimeout(timer);
          if (!res.ok) return Response.json({ place: null });
          const data = (await res.json()) as {
            city?: string;
            locality?: string;
            principalSubdivision?: string;
            countryName?: string;
          };
          const parts = [
            data.city || data.locality,
            data.principalSubdivision,
            data.countryName,
          ].filter((p): p is string => Boolean(p && p.trim()));
          const place = parts.length ? parts.join(", ") : null;
          return Response.json({ place });
        } catch {
          return Response.json({ place: null });
        }
      },
    },
  },
});

import { createFileRoute } from "@tanstack/react-router";
import { useAsk } from "@/components/site/ask";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How Sport Compass Works | Sports 4 All" },
      {
        name: "description",
        content:
          "How Sport Compass works: ask naturally, get grounded fencing guidance, see what it can and cannot answer, understand what is shared, and connect with real people.",
      },
      { property: "og:title", content: "How Sport Compass Works | Sports 4 All" },
      {
        property: "og:description",
        content: "One conversation. Trusted answers. Real next steps.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://sports-4-all.org/how-it-works" },
    ],
    links: [{ rel: "canonical", href: "https://sports-4-all.org/how-it-works" }],
  }),
  component: Page,
});

interface Step {
  title: string;
  body: string;
  example: string;
  answer: string;
}

const STEPS: readonly Step[] = [
  {
    title: "Ask naturally",
    body: "Type a question the way you would ask a coach — no forms, no jargon required. You can ask in your own words, in several languages, and follow up as many times as you like.",
    example: "Can my daughter fence from a wheelchair?",
    answer:
      "A plain-language explanation of wheelchair fencing, what clubs usually provide, and what to try first — plus follow-up suggestions you can tap.",
  },
  {
    title: "Get grounded guidance",
    body: "Sport Compass answers from trusted fencing information and clearly flags anything you should confirm with the governing body before relying on it.",
    example: "Find an accessible fencing program near Denver",
    answer:
      "What to look for in a welcoming club, what questions to ask when you call, and a pointer to USA Fencing's club finder for current availability.",
  },
  {
    title: "Connect with people",
    body: "When you are ready, ask a program specialist to follow up — only with what you choose to share, and only after you confirm.",
    example: "I'd like someone to help us get started",
    answer:
      "A short form asking for a name, a valid email address and the general reason for the request, sent to the organization only when you press send.",
  },
];

const CAN = [
  "General guidance on adaptive and wheelchair fencing",
  "How foil, épée and sabre differ, and which might suit you",
  "Equipment basics and what clubs typically provide",
  "What a first lesson usually looks like and how to prepare",
  "How the pathway from beginner to Paralympic competition is structured",
  "Questions worth asking a club before you visit",
];

const CANNOT = [
  "Official eligibility decisions",
  "Classification outcomes for para sport",
  "Qualification rules and current competition criteria",
  "Live club availability, schedules and pricing",
  "Medical, legal or coaching advice for an individual",
];

const FLOW = [
  ["You", "Type a question in the chat on this site."],
  ["This site", "Sends your question to our own server — never straight to a third party from your browser."],
  ["Sport Compass", "The Sports 4 All agent reads the question and works out what is being asked."],
  ["Trusted fencing information", "The answer is grounded in USA Fencing information, then returned to you."],
] as const;

function Page() {
  const ask = useAsk();
  return (
    <>
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <h1 className="font-display text-3xl font-extrabold sm:text-4xl">
          One Conversation. Trusted Answers. Real Next Steps.
        </h1>
        <p className="mt-4 max-w-3xl text-lg text-muted-foreground">
          Sport Compass is a guide, not a gatekeeper. Here is exactly what happens when you ask it something, what it
          can and cannot answer, and what — if anything — is shared with anyone else.
        </p>
        <ol className="mt-8 grid gap-5 md:grid-cols-3">
          {STEPS.map((step, i) => (
            <li key={step.title} className="rounded-3xl border border-border bg-card p-6 shadow-sm">
              <p className="font-display text-2xl font-extrabold text-primary">{i + 1}</p>
              <h2 className="mt-2 font-display text-xl font-bold">{step.title}</h2>
              <p className="mt-2 text-muted-foreground">{step.body}</p>
              <p className="mt-4 rounded-2xl bg-piste px-4 py-3 text-sm">
                <span className="font-semibold">You ask:</span> “{step.example}”
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">You get:</span> {step.answer}
              </p>
            </li>
          ))}
        </ol>
      </section>

      <section id="scope" aria-labelledby="scope-heading" className="bg-piste px-4 py-14 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <h2 id="scope-heading" className="font-display text-2xl font-extrabold sm:text-3xl">
            What Sport Compass can and can’t do
          </h2>
          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
              <h3 className="font-display text-lg font-bold">It can help with</h3>
              <ul className="mt-3 ml-5 list-disc space-y-2 text-muted-foreground">
                {CAN.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
              <h3 className="font-display text-lg font-bold">It always points you to USA Fencing for</h3>
              <ul className="mt-3 ml-5 list-disc space-y-2 text-muted-foreground">
                {CANNOT.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <p className="mt-4 text-sm text-muted-foreground">
                These change over time and are decided by the governing body, so Sport Compass says so plainly rather
                than guessing.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="sharing" aria-labelledby="sharing-heading" className="px-4 py-14 sm:px-6">
        <div className="mx-auto max-w-3xl">
          <h2 id="sharing-heading" className="font-display text-2xl font-extrabold sm:text-3xl">
            What gets shared, and when
          </h2>
          <ul className="mt-6 space-y-4 text-lg text-muted-foreground">
            <li>
              <span className="font-semibold text-foreground">Your questions stay in the conversation.</span> They are
              used to answer you, and aggregate counts are kept so we know the site is working — never the words you
              typed.
            </li>
            <li>
              <span className="font-semibold text-foreground">Nothing reaches the organization unless you ask.</span>{" "}
              Contact details are only sent when you fill in the follow-up form and press send, or when you agree to
              save your preferences.
            </li>
            <li>
              <span className="font-semibold text-foreground">Location is optional.</span> If the assistant asks where
              you are, you can share a place name from your browser or simply type your city — coordinates are never
              sent.
            </li>
            <li>
              <span className="font-semibold text-foreground">You can start over at any time.</span> “New conversation”
              clears the thread and begins fresh.
            </li>
          </ul>
        </div>
      </section>

      <section id="behind-the-scenes" aria-labelledby="behind-heading" className="bg-navy px-4 py-14 text-navy-foreground sm:px-6">
        <div className="mx-auto max-w-6xl">
          <h2 id="behind-heading" className="font-display text-2xl font-extrabold sm:text-3xl">
            Behind the scenes
          </h2>
          <ol className="mt-6 grid gap-4 md:grid-cols-4">
            {FLOW.map(([label, body], i) => (
              <li key={label} className="rounded-3xl border border-white/15 bg-white/5 p-6">
                <p className="text-sm font-semibold uppercase tracking-wide text-gold">Step {i + 1}</p>
                <h3 className="mt-2 font-display text-lg font-bold">{label}</h3>
                <p className="mt-2 text-navy-foreground/80">{body}</p>
              </li>
            ))}
          </ol>
          <p className="mt-6 max-w-3xl text-navy-foreground/80">
            Credentials, security tokens, internal instructions and raw error details stay on the server and never
            reach your browser. Powered by Salesforce Agentforce and Data Cloud.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <button
          type="button"
          onClick={() => ask()}
          className="min-h-11 rounded-full bg-primary px-6 font-semibold text-primary-foreground"
        >
          Ask Sport Compass
        </button>
      </section>
    </>
  );
}

import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/pathway")({
  beforeLoad: () => {
    throw redirect({ to: "/fencing-for-all", hash: "pathway" });
  },
});

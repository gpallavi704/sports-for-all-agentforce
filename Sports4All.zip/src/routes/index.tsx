import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { FencingChat } from "@/components/chat/FencingChat";
import { useAsk } from "@/components/site/ask";
import { OneAgentSection } from "@/components/site/OneAgentSection";
import { ResponsibleAiNote } from "@/components/site/ResponsibleAiNote";
import heroWheelchair from "@/assets/hero-wheelchair-fencer.jpg";
import heroStanding from "@/assets/hero-standing-fencer.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fencing for All | Sports 4 All — Every Body Belongs in Sport" },
      {
        name: "description",
        content:
          "Adaptive and standing fencing guidance for every athlete. Ask Sport Compass about wheelchair fencing, equipment, weapons, programs and competition pathways.",
      },
      { property: "og:title", content: "Every Body Belongs in Sport | Fencing for All" },
      {
        property: "og:description",
        content:
          "Explore adaptive fencing, find welcoming programs and get personalized next steps from Sport Compass.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://sports-4-all.org/" },
    ],
    links: [{ rel: "canonical", href: "https://sports-4-all.org/" }],
  }),
  component: Index,
});

const HASH_ROUTES: Record<string, string> = {
  "#fencing-for-all": "/fencing-for-all",
  "#explore": "/fencing-for-all",
  "#accessibility": "/accessibility",
  "#how-it-works": "/how-it-works",
  "#about": "/impact",
  "#privacy": "/impact",
};


function Hero() {
  const ask = useAsk();
  return (
    <section className="relative overflow-hidden bg-navy text-navy-foreground">
      <div className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-8 sm:px-6 lg:grid-cols-2 lg:py-10">
        <div>
          <p className="inline-flex rounded-full bg-white/10 px-4 py-1 text-sm font-semibold uppercase tracking-wide text-gold">
            Fencing for All
          </p>
          <h1 className="mt-3 font-display text-3xl font-extrabold leading-tight sm:text-5xl">
            Every Body Belongs in Sport.
          </h1>
          <p className="mt-3 max-w-xl text-base text-navy-foreground/90 sm:text-lg">
            Adaptive fencing is fast, tactical and fiercely competitive. There is a weapon, a club and a pathway built
            for you.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => ask()}
              className="min-h-11 rounded-full bg-gold px-6 font-semibold text-gold-foreground"
            >
              Ask Sport Compass
            </button>
            <Link
              to="/accessibility"
              className="inline-flex min-h-11 items-center rounded-full border border-white/40 px-6 font-semibold"
            >
              Explore Adaptive Fencing
            </Link>
          </div>
          <p className="mt-4 text-sm text-navy-foreground/80">
            Inclusive guidance. Trusted program information. Personalized next steps.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <img
            src={heroWheelchair}
            alt="A wheelchair fencer lunging with an épée during a bout"
            width={800}
            height={1000}
            className="h-40 w-full rounded-3xl object-cover shadow-2xl sm:h-56 lg:h-64"
          />
          <img
            src={heroStanding}
            alt="A standing fencer in white kit attacking on the piste"
            width={800}
            height={1000}
            loading="lazy"
            className="mt-6 h-40 w-full rounded-3xl object-cover shadow-2xl sm:h-56 lg:h-64"
          />
        </div>
      </div>
    </section>
  );
}

function ChatSection() {
  return (
    <section aria-labelledby="chat-heading" className="bg-piste px-4 py-10 sm:px-6">
      <h2 id="chat-heading" className="sr-only">
        Sport Compass
      </h2>
      <FencingChat />
      <ResponsibleAiNote />
      <p className="mx-auto mt-4 max-w-4xl text-center text-sm text-muted-foreground">
        Powered by Salesforce Agentforce + Data Cloud
      </p>
    </section>
  );
}

const EXPLORE_LINKS = [
  { to: "/fencing-for-all", title: "Fencing Is for Everyone", body: "Start at any age, adapt the sport, choose your weapon." },
  { to: "/fencing-for-all", hash: "weapons", title: "Foil, épée, and sabre", body: "Compare the three weapons side by side." },
  { to: "/accessibility", title: "Fencing From a Wheelchair", body: "How parafencing works and how to get started." },
  { to: "/fencing-for-all", hash: "pathway", title: "First Lesson to the Paralympics", body: "The six steps of the competition pathway." },
] as const;


function ExploreLinks() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <h2 className="font-display text-2xl font-extrabold sm:text-3xl">Explore fencing</h2>
      <ul className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {EXPLORE_LINKS.map((l) => (
          <li key={l.title}>
            <Link
              to={l.to}
              {...("hash" in l ? { hash: l.hash } : {})}
              className="flex h-full flex-col rounded-3xl border border-border bg-card p-6 shadow-sm hover:border-primary"
            >

              <h3 className="font-display text-lg font-bold">{l.title}</h3>
              <p className="mt-2 text-muted-foreground">{l.body}</p>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Index() {
  const navigate = useNavigate();
  useEffect(() => {
    const target = HASH_ROUTES[window.location.hash];
    if (target) void navigate({ to: target, replace: true });
  }, [navigate]);

  return (
    <>
      <Hero />
      <ChatSection />
      <ExploreLinks />
      <OneAgentSection />
    </>
  );
}


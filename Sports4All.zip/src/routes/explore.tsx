import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/explore")({
  beforeLoad: () => {
    throw redirect({ to: "/fencing-for-all", hash: "weapons" });
  },
});

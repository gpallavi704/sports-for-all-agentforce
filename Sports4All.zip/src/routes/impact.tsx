import { createFileRoute, Link } from "@tanstack/react-router";
import { ImpactSections } from "@/components/site/ImpactSections";

export const Route = createFileRoute("/impact")({
  head: () => ({
    meta: [
      { title: "Impact | Sports 4 All — Every Body Belongs in Sport" },
      {
        name: "description",
        content:
          "Why Sports 4 All exists, how it was built with USA Fencing and Agentforce, and the impact, responsible-AI and accessibility work behind Fencing for All.",
      },
      { property: "og:title", content: "Impact | Sports 4 All" },
      {
        property: "og:description",
        content: "One conversation that can open the door to many sports, starting with fencing.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://sports-4-all.org/impact" },
    ],
    links: [{ rel: "canonical", href: "https://sports-4-all.org/impact" }],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <section id="impact" className="bg-navy px-4 py-16 text-navy-foreground sm:px-6">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm font-semibold uppercase tracking-wide text-gold">Our impact</p>
          <h1 className="mt-2 max-w-4xl font-display text-3xl font-extrabold leading-tight sm:text-5xl">
            Fencing for All: Agentforce for Good
          </h1>
          <p className="mt-5 max-w-3xl text-lg text-navy-foreground/90">
            Sports 4 All exists so that every athlete — seated or standing, eight years old or eighty — can find a
            sport, a club and a next step. We present athletes with disabilities as athletes first.
          </p>
          <p className="mt-4 max-w-3xl text-navy-foreground/80">
            We start with fencing, created in collaboration with USA Fencing as part of the Salesforce Agentforce for
            Good Hackathon. Gymnastics, skiing, swimming, track and field and team sports will follow, so one
            conversation can open the door to many sports.
          </p>
          <p className="mt-4 max-w-3xl text-navy-foreground/80">
            Sport Compass is powered by Salesforce Agentforce and Data Cloud through the Sports 4 All MCP, with a
            consumer web experience and a ChatGPT Plugin driven by the same agent.
          </p>
          <Link
            to="/ask"
            className="mt-8 inline-flex min-h-11 items-center rounded-full bg-gold px-6 font-semibold text-navy"
          >
            Ask Sport Compass
          </Link>
        </div>
      </section>
      <ImpactSections />
    </>
  );
}

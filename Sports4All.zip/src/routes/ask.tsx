import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { FencingChat } from "@/components/chat/FencingChat";
import { parseTool } from "@/lib/chat/routing";

type AskSearch = { q?: string; intent?: string };

export const Route = createFileRoute("/ask")({
  validateSearch: (search: Record<string, unknown>): AskSearch => ({
    ...(typeof search['q'] === "string" && search['q'] ? { q: search['q'].slice(0, 1500) } : {}),
    ...(parseTool(search['intent']) ? { intent: parseTool(search['intent']) as string } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Ask Sport Compass | Sports 4 All" },
      {
        name: "description",
        content:
          "Ask Sport Compass about adaptive fencing, equipment, weapons, programs, accommodations and competition pathways.",
      },
      { property: "og:title", content: "Ask Sport Compass | Sports 4 All" },
      {
        property: "og:description",
        content: "Ask anything about fencing and get grounded guidance plus real next steps.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://sports-4-all.org/ask" },
    ],
    links: [{ rel: "canonical", href: "https://sports-4-all.org/ask" }],
  }),
  component: AskPage,
});

function AskPage() {
  const { q, intent } = Route.useSearch();
  const navigate = useNavigate();
  const sent = useRef(false);

  useEffect(() => {
    if (sent.current) return;
    sent.current = true;
    if (q) {
      window.dispatchEvent(new CustomEvent("s4a:ask", { detail: { question: q, intent } }));
      void navigate({ to: "/ask", search: {}, replace: true });
    }
  }, [q, intent, navigate]);

  return (
    <section className="bg-piste px-4 py-10 sm:px-6">
      <h1 className="mx-auto mb-6 max-w-4xl font-display text-3xl font-extrabold sm:text-4xl">Ask Sport Compass</h1>
      <FencingChat />
      <p className="mx-auto mt-4 max-w-4xl text-center text-sm text-muted-foreground">
        Powered by Salesforce Agentforce + Data Cloud
      </p>
    </section>
  );
}

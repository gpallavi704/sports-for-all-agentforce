/** Shared (browser-safe) types and tool-routing heuristics for the chat. */

export type ChatTool =
  | "ask_fencing_question"
  | "find_sports_programs"
  | "get_program_details"
  | "save_participant_preferences"
  | "request_human_assistance";

export interface ChatRequestBody {
  message?: string;
  language?: string;
  conversationContext?: string;
  action?: "message" | "reset" | "diagnostics" | "feedback";
  /** Anonymous rating of the previous answer (no question or answer text). */
  feedback?: "up" | "down";
  /** Explicit intent from a UI flow (program search, consented write actions). */
  intent?: ChatTool;
  /** Structured payload for the consented write tools. */
  details?: Record<string, unknown>;
  /** Opaque visitor token, used when the browser cannot return the cookie. */
  sessionToken?: string;
}

export interface ChatResponseBody {
  reply: string;
  followUps: string[];
  tool: ChatTool | null;
  programs: ProgramCard[];
  reference?: string | null;
  error?: "timeout" | "unavailable" | "expired" | "busy" | "invalid" | "config" | null;
  /** Opaque visitor token to send back on the next request (cookie fallback). */
  sessionToken?: string;
  configWarning?: string | null;
}

export interface ProgramCard {
  name: string;
  discipline?: string;
  organization?: string;
  location?: string;
  ageRange?: string;
  cost?: string;
  equipment?: string;
  accessibility?: string;
  whyMatch?: string;
  nextStep?: string;
}

const PROGRAM_HINTS = [
  "near me",
  "near us",
  "find a club",
  "find a program",
  "accessible club",
  "accessible program",
  "clubs in",
  "programs in",
  "zip code",
  "zipcode",
  "postcode",
  "postal code",
  "close to",
  "in my area",
  "local club",
  "local program",
];

/** Chooses the MCP tool for a free-text message. Education defaults to ask_fencing_question. */
export function routeTool(message: string, intent?: ChatTool): ChatTool {
  if (intent) return intent;
  const text = message.toLowerCase();
  if (/\b\d{5}\b/.test(text) && /(club|program|near|around|close)/.test(text)) {
    return "find_sports_programs";
  }
  if (PROGRAM_HINTS.some((hint) => text.includes(hint))) return "find_sports_programs";
  return "ask_fencing_question";
}

/** Coarse, non-identifying category recorded for analytics. Never the question itself. */
export function categorizeQuestion(message: string): string {
  const text = message.toLowerCase();
  if (/(wheelchair|para|adaptive|accessib|classif)/.test(text)) return "adaptive";
  if (/(epee|épée|foil|sabre|saber|weapon)/.test(text)) return "disciplines";
  if (/(equipment|gear|mask|jacket|glove)/.test(text)) return "equipment";
  if (/(paralymp|olymp|qualif|compet|rank)/.test(text)) return "competition";
  if (/(cost|price|scholarship|financial|afford)/.test(text)) return "cost";
  if (/(club|program|near|where)/.test(text)) return "programs";
  if (/(age|start|begin|young|old)/.test(text)) return "getting_started";
  return "general";
}

const CHAT_TOOLS: readonly ChatTool[] = [
  "ask_fencing_question",
  "find_sports_programs",
  "get_program_details",
  "save_participant_preferences",
  "request_human_assistance",
];

/** Narrows an untrusted string (URL search param, custom event) to a real tool name. */
export function parseTool(value: unknown): ChatTool | undefined {
  return typeof value === "string" && (CHAT_TOOLS as readonly string[]).includes(value)
    ? (value as ChatTool)
    : undefined;
}

/**
 * Server-side MCP client for the Sports 4 All consumer site.
 *
 * The browser never talks to this endpoint or to Salesforce directly; only the
 * `/api/sports-for-all-chat` handler uses this module.
 */

export interface McpToolDefinition {
  name: string;
  title?: string;
  description?: string;
  inputSchema?: unknown;
  annotations?: Record<string, unknown>;
}

interface JsonRpcResponse {
  jsonrpc: "2.0";
  id?: number | string;
  result?: Record<string, unknown>;
  error?: { code: number; message: string; data?: unknown };
}

const PROTOCOL_VERSION = "2025-06-18";
const TOOL_CACHE_TTL_MS = 60_000;
const REQUEST_TIMEOUT_MS = 45_000;

let toolCache: { tools: McpToolDefinition[]; fetchedAt: number; endpoint: string } | null = null;
let initializedFor: string | null = null;

function mcpEndpoint(requestUrl: string): string {
  const override = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process
    ?.env?.["MCP_ENDPOINT_URL"];
  if (override && override.trim()) return override.trim();
  return new URL("/api/public/mcp", requestUrl).toString();
}

/** Parses either a plain JSON body or a Streamable-HTTP SSE body. */
function parseBody(raw: string): JsonRpcResponse {
  const trimmed = raw.trim();
  if (trimmed.startsWith("{")) return JSON.parse(trimmed) as JsonRpcResponse;
  const dataLine = trimmed
    .split(/\r?\n/)
    .find((line) => line.startsWith("data:"));
  if (!dataLine) throw new Error("mcp_bad_response");
  return JSON.parse(dataLine.slice(5).trim()) as JsonRpcResponse;
}

let nextId = 1;

async function rpc(
  endpoint: string,
  method: string,
  params?: Record<string, unknown>,
  notification = false,
): Promise<JsonRpcResponse | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/event-stream",
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method,
        ...(notification ? {} : { id: nextId++ }),
        ...(params ? { params } : {}),
      }),
      signal: controller.signal,
    });

    if (!response.ok) throw new Error(`mcp_http_${response.status}`);
    if (notification) return null;

    const parsed = parseBody(await response.text());
    if (parsed.error) throw new Error(`mcp_error_${parsed.error.code}`);
    return parsed;
  } finally {
    clearTimeout(timer);
  }
}

async function ensureInitialized(endpoint: string): Promise<void> {
  if (initializedFor === endpoint) return;
  await rpc(endpoint, "initialize", {
    protocolVersion: PROTOCOL_VERSION,
    capabilities: {},
    clientInfo: { name: "sports-4-all-web", version: "1.0.0" },
  });
  await rpc(endpoint, "notifications/initialized", undefined, true);
  initializedFor = endpoint;
}

export async function listTools(requestUrl: string): Promise<McpToolDefinition[]> {
  const endpoint = mcpEndpoint(requestUrl);
  const now = Date.now();
  if (toolCache && toolCache.endpoint === endpoint && now - toolCache.fetchedAt < TOOL_CACHE_TTL_MS) {
    return toolCache.tools;
  }
  await ensureInitialized(endpoint);
  const result = await rpc(endpoint, "tools/list");
  const tools = ((result?.result?.["tools"] as McpToolDefinition[]) ?? []).map((t) => {
    const entry: McpToolDefinition = { name: t.name };
    if (t.title !== undefined) entry.title = t.title;
    if (t.description !== undefined) entry.description = t.description;
    if (t.annotations !== undefined) entry.annotations = t.annotations;
    return entry;
  });
  toolCache = { tools, fetchedAt: now, endpoint };
  return tools;
}

export interface McpToolCallResult {
  text: string;
  structured: Record<string, unknown>;
  isError: boolean;
}

export async function callTool(
  requestUrl: string,
  name: string,
  args: Record<string, unknown>,
): Promise<McpToolCallResult> {
  const endpoint = mcpEndpoint(requestUrl);
  await ensureInitialized(endpoint);
  const response = await rpc(endpoint, "tools/call", { name, arguments: args });
  const result = (response?.result ?? {}) as {
    content?: Array<{ type: string; text?: string }>;
    structuredContent?: Record<string, unknown>;
    isError?: boolean;
  };
  const text = (result.content ?? [])
    .filter((part) => part.type === "text" && part.text)
    .map((part) => part.text as string)
    .join("\n\n");
  return {
    text,
    structured: result.structuredContent ?? {},
    isError: Boolean(result.isError),
  };
}

/** Health probe used by the non-production diagnostics panel. */
export async function probeEndpoint(requestUrl: string): Promise<{
  endpointReachable: boolean;
  initialized: boolean;
  toolCount: number;
  askFencingQuestionAvailable: boolean;
  responseTimeMs: number;
}> {
  const started = Date.now();
  try {
    const tools = await listTools(requestUrl);
    return {
      endpointReachable: true,
      initialized: initializedFor !== null,
      toolCount: tools.length,
      askFencingQuestionAvailable: tools.some((t) => t.name === "ask_fencing_question"),
      responseTimeMs: Date.now() - started,
    };
  } catch {
    return {
      endpointReachable: false,
      initialized: false,
      toolCount: 0,
      askFencingQuestionAvailable: false,
      responseTimeMs: Date.now() - started,
    };
  }
}

/**
 * Detects whether the assistant's answer ends with a yes/no question, so the
 * chat can offer "Yes" / "No" quick replies.
 */

const AUX = [
  "am",
  "are",
  "is",
  "was",
  "were",
  "do",
  "does",
  "did",
  "can",
  "could",
  "will",
  "would",
  "shall",
  "should",
  "may",
  "might",
  "must",
  "have",
  "has",
  "had",
];

const WH = ["what", "when", "where", "which", "who", "whom", "whose", "why", "how"];

/** Returns the last sentence that ends in a question mark, if any. */
export function lastQuestion(text: string): string | undefined {
  const matches = text.match(/[^.!?\n]+\?/g);
  if (!matches || matches.length === 0) return undefined;
  return matches[matches.length - 1]!.trim();
}

export function isYesNoQuestion(text: string): boolean {
  const question = lastQuestion(text ?? "");
  if (!question) return false;

  // "A or B?" style choices are not yes/no.
  if (/\bor\b[^?]*\?$/i.test(question)) return false;

  const normalized = question.replace(/^[^A-Za-z]+/, "").toLowerCase();
  if (normalized.length === 0) return false;

  const firstWord = normalized.split(/[^a-z']+/)[0] ?? "";
  if (WH.includes(firstWord)) return false;

  if (AUX.includes(firstWord)) return true;
  if (/^(let me know if|would you like|want me to|shall i|do you want|are you|is that|does that|can i|should i)\b/.test(normalized)) {
    return true;
  }
  return false;
}

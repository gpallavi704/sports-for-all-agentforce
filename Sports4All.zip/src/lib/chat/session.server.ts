/**
 * Server-only session + analytics store for the consumer chat.
 *
 * The browser only ever holds an opaque random token (in an HttpOnly cookie).
 * Only its SHA-256 hash is stored, and the internal Agentforce session id
 * never leaves the server.
 */

const COOKIE_NAME = "s4a_chat";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;
const IDLE_TTL_MS = 1000 * 60 * 60 * 4;

export interface SessionRow {
  id: string;
  agentforce_session_id: string | null;
  next_sequence_id: number;
  language: string;
  status: string;
  request_in_progress: boolean;
  message_count: number;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export async function hashToken(token: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function newToken(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function readCookieToken(request: Request): string | null {
  const header = request.headers.get("cookie");
  if (!header) return null;
  for (const part of header.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === COOKIE_NAME) return decodeURIComponent(rest.join("=")) || null;
  }
  return null;
}

export function cookieHeader(token: string, secure: boolean): string {
  const maxAge = Math.floor(SESSION_TTL_MS / 1000);
  return [
    `${COOKIE_NAME}=${encodeURIComponent(token)}`,
    "Path=/",
    "HttpOnly",
    // SameSite=None is required for the chat to keep its session inside the
    // Lovable preview frame (a cross-site top-level context). Only valid with Secure.
    secure ? "SameSite=None" : "SameSite=Lax",
    `Max-Age=${maxAge}`,
    secure ? "Secure" : "",
  ]
    .filter(Boolean)
    .join("; ");
}

export async function createSession(tokenHash: string, language: string): Promise<SessionRow> {
  const db = await admin();
  const { data, error } = await db
    .from("agentforce_sessions")
    .insert({
      public_session_token_hash: tokenHash,
      language,
      expires_at: new Date(Date.now() + SESSION_TTL_MS).toISOString(),
    })
    .select(
      "id, agentforce_session_id, next_sequence_id, language, status, request_in_progress, message_count",
    )
    .single();
  if (error) throw new Error("session_create_failed");
  return data as SessionRow;
}

export async function loadSession(tokenHash: string): Promise<SessionRow | null> {
  const db = await admin();
  const { data } = await db
    .from("agentforce_sessions")
    .select(
      "id, agentforce_session_id, next_sequence_id, language, status, request_in_progress, message_count, last_activity_at, expires_at",
    )
    .eq("public_session_token_hash", tokenHash)
    .maybeSingle();
  if (!data) return null;

  const row = data as SessionRow & { last_activity_at: string; expires_at: string };
  const expired =
    row.status !== "active" ||
    new Date(row.expires_at).getTime() < Date.now() ||
    Date.now() - new Date(row.last_activity_at).getTime() > IDLE_TTL_MS;

  if (expired) {
    // Keep the row but drop the stale Agentforce conversation.
    await db
      .from("agentforce_sessions")
      .update({
        agentforce_session_id: null,
        next_sequence_id: 1,
        status: "active",
        request_in_progress: false,
        last_activity_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + SESSION_TTL_MS).toISOString(),
      })
      .eq("id", row.id);
    return {
      ...row,
      agentforce_session_id: null,
      next_sequence_id: 1,
      status: "active",
      request_in_progress: false,
    };
  }
  return row;
}

/** Atomically claims the session; returns null when a request is already running. */
export async function claimSession(sessionId: string): Promise<SessionRow | null> {
  const db = await admin();
  const { data } = await db
    .from("agentforce_sessions")
    .update({ request_in_progress: true, last_activity_at: new Date().toISOString() })
    .eq("id", sessionId)
    .eq("request_in_progress", false)
    .select(
      "id, agentforce_session_id, next_sequence_id, language, status, request_in_progress, message_count",
    )
    .maybeSingle();
  return (data as SessionRow | null) ?? null;
}

export async function releaseSession(
  sessionId: string,
  patch: Partial<{
    agentforce_session_id: string | null;
    next_sequence_id: number;
    language: string;
    status: string;
    last_tool_name: string;
    last_question_category: string;
    message_count: number;
  }> = {},
): Promise<void> {
  const db = await admin();
  await db
    .from("agentforce_sessions")
    .update({
      ...patch,
      request_in_progress: false,
      last_activity_at: new Date().toISOString(),
    })
    .eq("id", sessionId);
}

export async function resetSession(tokenHash: string): Promise<void> {
  const db = await admin();
  await db
    .from("agentforce_sessions")
    .update({
      agentforce_session_id: null,
      next_sequence_id: 1,
      status: "active",
      request_in_progress: false,
      message_count: 0,
      last_activity_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + SESSION_TTL_MS).toISOString(),
    })
    .eq("public_session_token_hash", tokenHash);
}

export interface ChatEvent {
  session_id?: string | null;
  event_type: string;
  question_category?: string | null;
  tool_name?: string | null;
  language?: string | null;
  success?: boolean | null;
  error_category?: string | null;
  response_time_ms?: number | null;
  human_escalation?: boolean;
  program_result_count?: number | null;
}

/** Records a privacy-conscious event. Never stores question or answer text. */
export async function trackEvent(event: ChatEvent): Promise<void> {
  try {
    const db = await admin();
    await db.from("chat_events").insert(event);
  } catch {
    // Analytics must never break the conversation.
  }
}

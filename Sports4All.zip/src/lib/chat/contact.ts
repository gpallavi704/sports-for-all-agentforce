/** Shared validation for the "ask a program specialist to follow up" form. */

const EMAIL_RE = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;

export function isValidEmail(value: string): boolean {
  const email = value.trim();
  if (email.length === 0 || email.length > 254) return false;
  return EMAIL_RE.test(email);
}

export function emailError(value: string): string | undefined {
  if (value.trim().length === 0) return "Enter an email address so a specialist can reply.";
  if (!isValidEmail(value)) return "Enter a valid email address, for example name@example.com.";
  return undefined;
}

export function phoneError(value: string): string | undefined {
  const digits = value.replace(/\D/g, "");
  if (value.trim().length === 0) return "Enter a phone number, or choose email as your preferred contact method.";
  if (digits.length < 7 || digits.length > 15) return "Enter a valid phone number.";
  return undefined;
}

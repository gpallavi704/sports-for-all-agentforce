import { describe, expect, it } from "vitest";
import { emailError, isValidEmail, phoneError } from "../contact";

describe("isValidEmail", () => {
  it("accepts ordinary addresses", () => {
    expect(isValidEmail("name@example.com")).toBe(true);
    expect(isValidEmail(" first.last+tag@sub.example.co.uk ")).toBe(true);
  });
  it("rejects malformed addresses", () => {
    for (const bad of ["", "   ", "name", "name@", "@example.com", "name@example", "na me@example.com", "a@b@c.com"]) {
      expect(isValidEmail(bad)).toBe(false);
    }
  });
  it("rejects addresses over 254 characters", () => {
    expect(isValidEmail(`${"a".repeat(250)}@example.com`)).toBe(false);
  });
});

describe("emailError", () => {
  it("asks for an address when empty", () => {
    expect(emailError("  ")).toMatch(/Enter an email address/);
  });
  it("flags an invalid address", () => {
    expect(emailError("nope")).toMatch(/valid email/);
  });
  it("returns nothing for a valid address", () => {
    expect(emailError("name@example.com")).toBeUndefined();
  });
});

describe("phoneError", () => {
  it("requires a value", () => {
    expect(phoneError("")).toBeTruthy();
  });
  it("rejects too few digits", () => {
    expect(phoneError("12345")).toBeTruthy();
  });
  it("accepts a normal number", () => {
    expect(phoneError("+1 (303) 555-0142")).toBeUndefined();
  });
});

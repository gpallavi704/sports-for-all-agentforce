import { describe, expect, it } from "vitest";
import { isYesNoQuestion } from "@/lib/chat/quick-replies";

describe("isYesNoQuestion", () => {
  it("detects auxiliary-led questions", () => {
    expect(isYesNoQuestion("Yes, athletes can fence seated. Would you like tips on finding a local club?")).toBe(true);
    expect(isYesNoQuestion("Is your daughter new to fencing?")).toBe(true);
    expect(isYesNoQuestion("Do you want me to look for programs nearby?")).toBe(true);
  });

  it("ignores wh-questions and choices", () => {
    expect(isYesNoQuestion("What city are you in?")).toBe(false);
    expect(isYesNoQuestion("Would you prefer foil or sabre?")).toBe(false);
    expect(isYesNoQuestion("Here is some information about parafencing.")).toBe(false);
    expect(isYesNoQuestion("")).toBe(false);
  });
});

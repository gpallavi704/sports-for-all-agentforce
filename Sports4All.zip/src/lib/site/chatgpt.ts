/**
 * ChatGPT Plugin link. Configured through the VITE_CHATGPT_PLUGIN_URL
 * environment setting. When it is missing we show an honest informational
 * state instead of a dead link.
 */
export function chatgptPluginUrl(): string | null {
  const raw = (import.meta.env["VITE_CHATGPT_PLUGIN_URL"] as string | undefined)?.trim();
  if (!raw) return null;
  if (!/^https?:\/\//i.test(raw)) return null;
  return raw;
}

/**
 * Salesforce Agentforce client for the Sports for All MCP server.
 *
 * Import-safe by design: no env reads, I/O, or throwing at module scope.
 * Every secret is resolved inside the exported functions at request time.
 */

type RuntimeGlobals = typeof globalThis & {
  Deno?: { env?: { get?: (name: string) => string | undefined } };
  process?: { env?: Record<string, string | undefined> };
};

function env(name: string): string | undefined {
  const runtime = globalThis as RuntimeGlobals;
  const value = runtime.Deno?.env?.get?.(name) ?? runtime.process?.env?.[name];
  const trimmed = value?.trim();
  return trimmed ? trimmed : undefined;
}

function requiredEnv(name: string): string {
  const value = env(name);
  if (!value) {
    throw new Error(
      `Missing required secret ${name}. Add it in the project's Secrets settings.`,
    );
  }
  return value;
}

export function mockEnabled(): boolean {
  return (env("MOCK_AGENTFORCE") ?? "").toLowerCase() === "true";
}

function myDomainUrl(): string {
  return requiredEnv("SALESFORCE_MY_DOMAIN_URL").replace(/\/+$/, "");
}

function agentApiBaseUrl(): string {
  return (env("AGENTFORCE_API_BASE_URL") ?? "https://api.salesforce.com/einstein/ai-agent/v1")
    .replace(/\/+$/, "");
}

/**
 * Strips anything that could carry a credential out of an error before it
 * reaches an MCP client. Never let a raw Salesforce body through.
 */
export function safeErrorMessage(error: unknown): string {
  const raw = error instanceof Error ? error.message : String(error);
  return raw
    .replace(/Bearer\s+[A-Za-z0-9._!\-]+/gi, "Bearer [redacted]")
    .replace(/00D[A-Za-z0-9!._\-]{10,}/g, "[redacted]")
    .replace(/(access_token"?\s*[:=]\s*"?)[^",\s}]+/gi, "$1[redacted]")
    .replace(/(client_secret"?\s*[:=]\s*"?)[^",\s}]+/gi, "$1[redacted]")
    .slice(0, 600);
}

// ---------------------------------------------------------------------------
// OAuth token: minted with client credentials, cached in memory only.
// ---------------------------------------------------------------------------

let cachedToken: { token: string; expiresAt: number } | null = null;
const EXPIRY_SKEW_MS = 60_000;

async function getAccessToken(signal?: AbortSignal): Promise<string> {
  const now = Date.now();
  if (cachedToken && cachedToken.expiresAt - EXPIRY_SKEW_MS > now) {
    return cachedToken.token;
  }

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: requiredEnv("SALESFORCE_CLIENT_ID"),
    client_secret: requiredEnv("SALESFORCE_CLIENT_SECRET"),
  });

  const response = await fetch(`${myDomainUrl()}/services/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    ...(signal ? { signal } : {}),
  });

  if (!response.ok) {
    throw new Error(
      `Salesforce token request failed with status ${response.status}. Check the connected app's client credentials configuration.`,
    );
  }

  const json = (await response.json()) as {
    access_token?: string;
    expires_in?: number;
  };
  if (!json.access_token) {
    throw new Error("Salesforce token response did not contain an access token.");
  }

  // Salesforce client-credentials tokens frequently omit expires_in; assume a
  // conservative short lifetime so the cache never outlives the token.
  const lifetimeMs = (json.expires_in ?? 900) * 1000;
  cachedToken = { token: json.access_token, expiresAt: Date.now() + lifetimeMs };
  return cachedToken.token;
}

// ---------------------------------------------------------------------------
// Agentforce Agent API
// ---------------------------------------------------------------------------

export interface AgentTurnOptions {
  /** Continue an existing Agentforce session instead of starting a new one. */
  sessionId?: string | undefined;
  /** Next sequence number within an existing session. */
  sequenceId?: number | undefined;
  /** Preferred answer language, forwarded as an Agentforce session variable. */
  language?: string | undefined;
  signal?: AbortSignal | undefined;
}

export interface AgentTurnResult {
  sessionId: string;
  sequenceId: number;
  text: string;
  mock: boolean;
}

/** Session ids with a message currently in flight (no concurrent turns allowed). */
const inFlightSessions = new Set<string>();

export class SessionBusyError extends Error {
  constructor(sessionId: string) {
    super(`Agentforce session ${sessionId} already has a message in progress.`);
    this.name = "SessionBusyError";
  }
}

async function startSession(
  token: string,
  signal?: AbortSignal,
  language?: string,
): Promise<string> {
  const agentId = requiredEnv("SALESFORCE_AGENT_ID");
  const bypassUser = (env("AGENTFORCE_BYPASS_USER") ?? "true").toLowerCase() === "true";

  const response = await fetch(`${agentApiBaseUrl()}/agents/${encodeURIComponent(agentId)}/sessions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      externalSessionKey: crypto.randomUUID(),
      instanceConfig: { endpoint: myDomainUrl() },
      streamingCapabilities: { chunkTypes: ["Text"] },
      bypassUser,
      ...(language
        ? {
            variables: [
              {
                name: "$Context.EndUserLanguage",
                type: "Text",
                value: language,
              },
            ],
          }
        : {}),
    }),
    ...(signal ? { signal } : {}),
  });

  if (!response.ok) {
    throw new Error(`Agentforce session start failed with status ${response.status}.`);
  }

  const json = (await response.json()) as { sessionId?: string };
  if (!json.sessionId) {
    throw new Error("Agentforce session start returned no session id.");
  }
  return json.sessionId;
}


interface AgentMessagePayload {
  messages?: Array<{ message?: string; type?: string }>;
}

function extractText(payload: AgentMessagePayload): string {
  const parts = (payload.messages ?? [])
    .map((m) => (typeof m.message === "string" ? m.message.trim() : ""))
    .filter(Boolean);
  return parts.length ? parts.join("\n\n") : "The agent returned no text for this request.";
}

function mockReply(prompt: string, options: AgentTurnOptions): AgentTurnResult {
  const sequenceId = (options.sequenceId ?? 0) + 1;
  return {
    sessionId: options.sessionId ?? "mock-session",
    sequenceId,
    mock: true,
    text: `[MOCK_AGENTFORCE] No Salesforce call was made. The agent would have received:\n\n${prompt}`,
  };
}

/**
 * Sends one synchronous text turn to the Agentforce agent, starting a session
 * first when the caller did not supply one.
 */
export async function sendAgentMessage(
  prompt: string,
  options: AgentTurnOptions = {},
): Promise<AgentTurnResult> {
  if (mockEnabled()) return mockReply(prompt, options);

  if (options.sessionId && inFlightSessions.has(options.sessionId)) {
    throw new SessionBusyError(options.sessionId);
  }

  const token = await getAccessToken(options.signal);
  const sessionId =
    options.sessionId ?? (await startSession(token, options.signal, options.language));
  const sequenceId = (options.sequenceId ?? 0) + 1;

  inFlightSessions.add(sessionId);
  let response: Response;
  try {
    response = await fetch(
      `${agentApiBaseUrl()}/sessions/${encodeURIComponent(sessionId)}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: { sequenceId, type: "Text", text: prompt },
        }),
        ...(options.signal ? { signal: options.signal } : {}),
      },
    );
  } finally {
    inFlightSessions.delete(sessionId);
  }

  if (!response.ok) {
    throw new Error(`Agentforce message request failed with status ${response.status}.`);
  }


  const json = (await response.json()) as AgentMessagePayload;
  return { sessionId, sequenceId, text: extractText(json), mock: false };
}

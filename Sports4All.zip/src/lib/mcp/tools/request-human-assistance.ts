import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { buildPrompt, runAgentTool, sessionFields } from "../shared";

export default defineTool({
  name: "request_human_assistance",
  title: "Request human assistance",
  description:
    "Hand the conversation to a Sports for All staff member, passing along the participant's contact details, question, and urgency.",
  inputSchema: {
    reason: z
      .string()
      .trim()
      .min(1)
      .max(1000)
      .describe("Why a person is needed and what the participant is trying to do."),
    participant_name: z.string().trim().max(120).optional().describe("Participant's name."),
    contact_email: z.string().trim().email().max(200).optional().describe("Contact email address."),
    contact_phone: z.string().trim().max(40).optional().describe("Contact phone number."),
    preferred_contact_method: z
      .enum(["email", "phone", "either"])
      .optional()
      .describe("How the participant prefers to be reached."),
    urgency: z.enum(["low", "normal", "high"]).optional().describe("How urgent the request is."),
    ...sessionFields,
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: true },
  handler: async (args, ctx) => {
    const prompt = buildPrompt(
      "Escalate this conversation to a human Sports for All team member and confirm to the participant what happens next.",
      {
        reason: args.reason,
        participant_name: args.participant_name,
        contact_email: args.contact_email,
        contact_phone: args.contact_phone,
        preferred_contact_method: args.preferred_contact_method,
        urgency: args.urgency ?? "normal",
      },
    );
    return runAgentTool(prompt, args, ctx);
  },
});

import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { buildPrompt, runAgentTool, sessionFields } from "../shared";

export default defineTool({
  name: "save_participant_preferences",
  title: "Save participant preferences",
  description:
    "Record a participant's sport, location, schedule, and accessibility preferences with the Sports for All agent so future recommendations match them.",
  inputSchema: {
    participant_name: z
      .string()
      .trim()
      .max(120)
      .optional()
      .describe("Participant's name or preferred name."),
    contact_email: z.string().trim().email().max(200).optional().describe("Contact email address."),
    location: z.string().trim().max(200).optional().describe("Preferred location or area."),
    sports: z
      .array(z.string().trim().max(80))
      .max(15)
      .optional()
      .describe("Sports or activities of interest."),
    participant_age: z.number().int().min(0).max(120).optional().describe("Participant's age."),
    accessibility_needs: z
      .string()
      .trim()
      .max(500)
      .optional()
      .describe("Adaptive or accessibility requirements."),
    schedule_preference: z
      .string()
      .trim()
      .max(300)
      .optional()
      .describe("Preferred days, times, or season."),
    notes: z.string().trim().max(1000).optional().describe("Anything else worth recording."),
    ...sessionFields,
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: true },
  handler: async (args, ctx) => {
    const prompt = buildPrompt(
      "Save the following participant preferences for future Sports for All program recommendations, then confirm what was recorded.",
      {
        participant_name: args.participant_name,
        contact_email: args.contact_email,
        location: args.location,
        sports: args.sports,
        participant_age: args.participant_age,
        accessibility_needs: args.accessibility_needs,
        schedule_preference: args.schedule_preference,
        notes: args.notes,
      },
    );
    return runAgentTool(prompt, args, ctx);
  },
});

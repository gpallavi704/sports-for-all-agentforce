import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { buildPrompt, runAgentTool, sessionFields } from "../shared";

export default defineTool({
  name: "get_program_details",
  title: "Get program details",
  description:
    "Retrieve full details for a single Sports for All program: schedule, location, eligibility, cost, accessibility, and registration steps.",
  inputSchema: {
    program_id: z
      .string()
      .trim()
      .max(120)
      .optional()
      .describe("Program identifier, when known."),
    program_name: z
      .string()
      .trim()
      .max(200)
      .optional()
      .describe("Program name, used when no identifier is available."),
    question: z
      .string()
      .trim()
      .max(600)
      .optional()
      .describe("A specific question about this program."),
    ...sessionFields,
  },
  annotations: { readOnlyHint: true, openWorldHint: true },
  handler: async (args, ctx) => {
    const prompt = buildPrompt(
      "Provide full details for the following Sports for All program, including schedule, location, eligibility, cost, accessibility support, and registration steps.",
      {
        program_id: args.program_id,
        program_name: args.program_name,
        question: args.question,
      },
    );
    return runAgentTool(prompt, args, ctx);
  },
});

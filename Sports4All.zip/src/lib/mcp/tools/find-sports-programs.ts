import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { buildPrompt, runAgentTool, sessionFields } from "../shared";

export default defineTool({
  name: "find_sports_programs",
  title: "Find sports programs",
  description:
    "Search Sports for All programs by location, sport, participant age, and other preferences. Returns matching programs described in plain text.",
  inputSchema: {
    location: z
      .string()
      .trim()
      .min(1)
      .max(200)
      .describe("City, neighborhood, postal code, or region to search near."),
    sport: z.string().trim().max(120).optional().describe("Sport or activity of interest."),
    participant_age: z
      .number()
      .int()
      .min(0)
      .max(120)
      .optional()
      .describe("Age of the person who would participate."),
    accessibility_needs: z
      .string()
      .trim()
      .max(500)
      .optional()
      .describe("Adaptive, accessibility, or support needs to account for."),
    schedule_preference: z
      .string()
      .trim()
      .max(300)
      .optional()
      .describe("Preferred days, times, or season."),
    max_results: z.number().int().min(1).max(25).optional().describe("Maximum programs to return."),
    ...sessionFields,
  },
  annotations: { readOnlyHint: true, openWorldHint: true },
  handler: async (args, ctx) => {
    const prompt = buildPrompt(
      "A participant is looking for Sports for All programs. Find suitable programs and summarize each with its name, location, schedule, age range, and how to register.",
      {
        location: args.location,
        sport: args.sport,
        participant_age: args.participant_age,
        accessibility_needs: args.accessibility_needs,
        schedule_preference: args.schedule_preference,
        max_results: args.max_results ?? 5,
      },
    );
    return runAgentTool(prompt, args, ctx);
  },
});

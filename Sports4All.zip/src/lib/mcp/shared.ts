import { ToolError, type ToolContext, type ToolHandlerResult } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { safeErrorMessage, sendAgentMessage } from "./agentforce";

/** Common optional fields every tool accepts so a conversation can continue. */
export const sessionFields = {
  session_id: z
    .string()
    .trim()
    .max(200)
    .optional()
    .describe("Existing Agentforce session id to continue. Omit to start a new session."),
  sequence_id: z
    .number()
    .int()
    .min(0)
    .max(10_000)
    .optional()
    .describe("Last sequence id used in the existing session. Omit for a new session."),
};

export interface SessionArgs {
  session_id?: string | undefined;
  sequence_id?: number | undefined;
}

/** Renders a labelled prompt block, skipping empty values and capping length. */
export function buildPrompt(intro: string, fields: Record<string, unknown>): string {
  const lines = Object.entries(fields)
    .filter(([, v]) => v !== undefined && v !== null && `${v}`.trim() !== "")
    .map(([k, v]) => `- ${k.replace(/_/g, " ")}: ${Array.isArray(v) ? v.join(", ") : String(v)}`);
  const prompt = [intro, ...lines].join("\n");
  return prompt.slice(0, 6000);
}

/** Runs one Agentforce turn and shapes it into an MCP tool result. */
export async function runAgentTool(
  prompt: string,
  args: SessionArgs,
  ctx: ToolContext,
): Promise<ToolHandlerResult> {
  try {
    const result = await sendAgentMessage(prompt, {
      sessionId: args.session_id,
      sequenceId: args.sequence_id,
      signal: ctx.signal,
    });
    return {
      content: [{ type: "text", text: result.text }],
      structuredContent: {
        text: result.text,
        session_id: result.sessionId,
        sequence_id: result.sequenceId,
        mock: result.mock,
      },
    };
  } catch (error) {
    throw new ToolError(safeErrorMessage(error));
  }
}

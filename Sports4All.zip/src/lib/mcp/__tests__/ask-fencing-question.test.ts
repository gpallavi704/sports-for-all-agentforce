import { beforeEach, describe, expect, it, vi } from "vitest";
import { z } from "zod";


const sendAgentMessage = vi.fn();
const mockEnabled = vi.fn(() => false);

vi.mock("../agentforce", async () => {
  const actual = await vi.importActual<typeof import("../agentforce")>("../agentforce");
  return {
    ...actual,
    mockEnabled: () => mockEnabled(),
    sendAgentMessage: (...args: unknown[]) => sendAgentMessage(...args),
  };
});

const { default: askFencingQuestion, askFencingQuestionSchema, extractFollowUpQuestions } =
  await import("../tools/ask-fencing-question");
const { default: mcp } = await import("../index");
const { default: findSportsPrograms } = await import("../tools/find-sports-programs");

const ctx = { signal: undefined } as never;

function parse(input: unknown) {
  return z.object(askFencingQuestionSchema).parse(input);
}


function sc(result: { structuredContent?: unknown }): Record<string, unknown> {
  return (result.structuredContent ?? {}) as Record<string, unknown>;
}

function firstContent(result: { content?: unknown }): unknown {
  return ((result.content ?? []) as unknown[])[0];
}

async function call(input: Record<string, unknown>) {
  return askFencingQuestion.handler(parse(input) as never, ctx);
}

beforeEach(() => {
  sendAgentMessage.mockReset();
  mockEnabled.mockReturnValue(false);
  sendAgentMessage.mockResolvedValue({
    sessionId: "sess-1",
    sequenceId: 1,
    text: "Yes — wheelchair fencing is an established discipline.\n\nWould you like to know what equipment she would need?",
    mock: false,
  });
});

describe("tool registration", () => {
  it("registers ask_fencing_question alongside the existing tools", () => {
    const names = mcp.tools.map((t: { name: string }) => t.name);
    expect(names).toContain("ask_fencing_question");
    expect(names).toEqual(
      expect.arrayContaining([
        "find_sports_programs",
        "get_program_details",
        "save_participant_preferences",
        "request_human_assistance",
      ]),
    );
    expect(names).toHaveLength(5);
  });

  it("is read-only and non-destructive", () => {
    expect(askFencingQuestion.annotations).toMatchObject({
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    });
  });
});

describe("input validation", () => {
  it("requires a question", () => {
    expect(() => parse({})).toThrow();
    expect(sendAgentMessage).not.toHaveBeenCalled();
  });

  it("rejects an empty question", () => {
    expect(() => parse({ question: "   " })).toThrow();
    expect(sendAgentMessage).not.toHaveBeenCalled();
  });

  it("rejects a question longer than 1500 characters", () => {
    expect(() => parse({ question: "a".repeat(1501) })).toThrow();
    expect(sendAgentMessage).not.toHaveBeenCalled();
  });

  it("rejects invalid sequence ids", () => {
    expect(() => parse({ question: "hi there", sequence_id: 0 })).toThrow();
    expect(() => parse({ question: "hi there", sequence_id: 1001 })).toThrow();
    expect(() => parse({ question: "hi there", sequence_id: 1.5 })).toThrow();
    expect(sendAgentMessage).not.toHaveBeenCalled();
  });
});

describe("agent interaction", () => {
  it("defaults the language to en", async () => {
    const result = await call({ question: "Can my daughter fence from a wheelchair?" });
    expect(sc(result)["language"]).toBe("en");
    expect(sendAgentMessage.mock.calls[0]?.[1]).toMatchObject({ language: "en" });
  });

  it("starts a new session when no session id is supplied", async () => {
    await call({ question: "What equipment does a beginner need?" });
    expect(sendAgentMessage.mock.calls[0]?.[1]?.sessionId).toBeUndefined();
  });

  it("reuses an existing session when a session id is supplied", async () => {
    sendAgentMessage.mockResolvedValue({
      sessionId: "sess-1",
      sequenceId: 2,
      text: "She would need a wheelchair-fencing frame and standard protective kit.",
      mock: false,
    });
    const result = await call({
      question: "What equipment would she need?",
      agentforce_session_id: "sess-1",
      sequence_id: 2,
    });
    expect(sendAgentMessage.mock.calls[0]?.[1]?.sessionId).toBe("sess-1");
    expect(sc(result)["agentforce_session_id"]).toBe("sess-1");
  });

  it("increments the sequence id correctly", async () => {
    const result = await call({ question: "How does wheelchair fencing work?" });
    expect(sc(result)["next_sequence_id"]).toBe(2);
  });

  it("returns the agent's answer rather than a locally generated one", async () => {
    sendAgentMessage.mockResolvedValue({
      sessionId: "sess-9",
      sequenceId: 1,
      text: "AGENT-GENERATED-ANSWER",
      mock: false,
    });
    const result = await call({ question: "What is the difference between epee and foil?" });
    expect(firstContent(result)).toMatchObject({ text: "AGENT-GENERATED-ANSWER" });
    expect(sc(result)["answer"]).toBe("AGENT-GENERATED-ANSWER");
  });

  it("only surfaces follow-up questions the agent actually wrote", () => {
    expect(extractFollowUpQuestions("Plain answer with no questions.")).toEqual([]);
    expect(
      extractFollowUpQuestions("Answer.\n- Would you like help finding a club nearby?"),
    ).toEqual(["Would you like help finding a club nearby?"]);
  });
});

describe("safe errors", () => {
  it("never leaks credentials or raw Salesforce errors", async () => {
    sendAgentMessage.mockRejectedValue(
      new Error('Agentforce failed: access_token="00Dxx0000001gPzEAI.abcdef" client_secret="hunter2"'),
    );
    await expect(call({ question: "How do you qualify for the Paralympics?" })).rejects.toThrow(
      /temporarily unavailable|no longer available/,
    );
    const message = await call({ question: "How do you qualify for the Paralympics?" }).catch(
      (e: Error) => e.message,
    );
    expect(message).not.toMatch(/hunter2|00Dxx|access_token/);
  });
});

describe("mock mode", () => {
  it("returns a clearly labelled mock answer and skips Salesforce", async () => {
    mockEnabled.mockReturnValue(true);
    const result = await call({ question: "At what age can someone start fencing?", language: "es" });
    expect(sendAgentMessage).not.toHaveBeenCalled();
    expect(sc(result)).toMatchObject({
      agentforce_session_id: "mock-session",
      next_sequence_id: 2,
      language: "es",
      mock: true,
    });
    expect(String(sc(result)["answer"])).toContain("MOCK RESPONSE");
  });
});

describe("existing tools", () => {
  it("still build prompts and return agent results", async () => {
    sendAgentMessage.mockResolvedValue({
      sessionId: "sess-2",
      sequenceId: 1,
      text: "Here are some programs.",
      mock: false,
    });
    const result = await findSportsPrograms.handler(
      { location: "Denver, CO", sport: "fencing" } as never,
      ctx,
    );
    expect(firstContent(result)).toMatchObject({ text: "Here are some programs." });
    expect(String(sendAgentMessage.mock.calls[0]?.[0])).toContain("Denver, CO");
  });
});

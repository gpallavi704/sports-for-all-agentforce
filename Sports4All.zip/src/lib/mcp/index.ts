import { defineMcp } from "@lovable.dev/mcp-js";
import findSportsPrograms from "./tools/find-sports-programs";
import getProgramDetails from "./tools/get-program-details";
import saveParticipantPreferences from "./tools/save-participant-preferences";
import requestHumanAssistance from "./tools/request-human-assistance";
import askFencingQuestion from "./tools/ask-fencing-question";

export default defineMcp({
  name: "sports-for-all-mcp",
  title: "Sports for All MCP",
  version: "0.1.0",
  instructions:
    "Tools for Sports for All, backed by a Salesforce Agentforce agent. Use `find_sports_programs` to search inclusive sports programs, `get_program_details` for a single program, `ask_fencing_question` for general educational questions about fencing, wheelchair fencing, equipment, and competition pathways, `save_participant_preferences` to record what a participant is looking for, and `request_human_assistance` to hand off to staff. Each tool returns session and sequence identifiers; pass them back on the next call to continue the same agent conversation.",
  tools: [
    findSportsPrograms,
    getProgramDetails,
    askFencingQuestion,
    saveParticipantPreferences,
    requestHumanAssistance,
  ],
});

